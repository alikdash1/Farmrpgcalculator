importScripts("shared/numbers.js", "shared/sanitize.js", "shared/schema.js", "shared/merge.js");

const EXPECTED = ["profile", "inventory", "tower", "mastery", "quests-available", "quests-completed", "perks", "farm-supply", "pets", "craftworks", "kitchen", "friendships"];

async function rebuild(captures) {
  const rows = Object.values(captures || {}).filter(Boolean);
  if (!rows.length) return null;
  const snapshot = ImporterShared.mergeCaptures(rows);
  snapshot.legacyV1 = ImporterShared.buildLegacyV1(snapshot);
  return snapshot;
}

async function status() {
  const data = await chrome.storage.local.get(["captures", "snapshot", "syncedAt"]);
  const captured = Object.keys(data.captures || {}).sort();
  return { snapshot: data.snapshot || null, syncedAt: data.syncedAt || null, captured, missing: EXPECTED.filter((name) => !captured.includes(name)) };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    if (!message || !message.type) return sendResponse({ ok: false, error: "Missing message type" });
    if (message.type === "farmrpg-account-capture") {
      const rawBytes = new TextEncoder().encode(JSON.stringify(message.capture || {})).length;
      const checked = ImporterShared.validateCapture(message.capture, rawBytes);
      if (!checked.ok) return sendResponse({ ok: false, error: checked.errors.join("; ") });
      const masteryRows = checked.capture.pageType === "mastery"
        ? (((checked.capture.fields || {}).masteries || []).length)
        : null;
      // Never replace a useful mastery capture with Farm RPG's loading shell.
      // This was the source of the calculator reverting to its August fallback.
      if (checked.capture.pageType === "mastery" && masteryRows === 0) {
        return sendResponse({
          ok: false,
          pageType: "mastery",
          rowCount: 0,
          error: "No mastery rows found. Wait for Mastery In-Progress to load, then press Sync again.",
        });
      }
      const data = await chrome.storage.local.get(["captures"]);
      const captures = data.captures || {};
      checked.capture._fileName = message.filename || checked.capture.pageType + ".json";
      const old = captures[checked.capture.pageType];
      if (!old || String(checked.capture.capturedAt) >= String(old.capturedAt)) captures[checked.capture.pageType] = checked.capture;
      const snapshot = await rebuild(captures);
      const syncedAt = new Date().toISOString();
      await chrome.storage.local.set({ captures, snapshot, syncedAt });
      return sendResponse({ ok: true, pageType: checked.capture.pageType, rowCount: masteryRows, captured: Object.keys(captures).length, syncedAt });
    }
    if (message.type === "farmrpg-account-status") return sendResponse({ ok: true, ...(await status()) });
    if (message.type === "farmrpg-account-clear") {
      await chrome.storage.local.remove(["captures", "snapshot", "syncedAt"]);
      return sendResponse({ ok: true });
    }
    if (message.type === "farmrpg-capture-active") {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tabs[0] || !tabs[0].id) return sendResponse({ ok: false, error: "No active tab" });
      try { return sendResponse(await chrome.tabs.sendMessage(tabs[0].id, { type: "farmrpg-capture-now" })); }
      catch (_) { return sendResponse({ ok: false, error: "Open a Farm RPG page first" }); }
    }
    return sendResponse({ ok: false, error: "Unknown message" });
  })().catch((error) => sendResponse({ ok: false, error: String(error && error.message || error) }));
  return true;
});
