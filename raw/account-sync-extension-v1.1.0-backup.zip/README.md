# Farm RPG Personal Account Sync

This extension keeps your calculator updated from the **Farm RPG pages you visit**. It is read-only: it does not click, navigate, craft, sell, explore, fish, trade, or send your data to a server.

## Install in Brave

1. Open `brave://extensions`.
2. Turn on **Developer mode** in the upper-right.
3. Choose **Load unpacked**.
4. Select this folder: `C:\Users\user\Desktop\FarmRPG Calculator Research\calculator\collectors\account-sync-extension`
5. Keep using Farm RPG normally. A small **Account sync** pill confirms which open page was learned.
6. Open the calculator at [http://127.0.0.1:8772/index.html#tower](http://127.0.0.1:8772/index.html#tower). The **My Tower** tab refreshes whenever the extension learns a newer page.

The extension cannot learn a page you have never opened. Its popup lists the useful page types still missing. The calculator's manual JSON import remains available as a backup.

If you open the calculator directly with a `file:///` address, open this extension's **Details** page and enable **Allow access to file URLs**. Using the local `127.0.0.1:8772` address is preferred.
