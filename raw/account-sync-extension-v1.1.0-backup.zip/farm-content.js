(() => {
  if (globalThis.__farmRpgAccountSyncLoaded) return;
  globalThis.__farmRpgAccountSyncLoaded = true;
  let timer = 0;
  let lastRoute = "";

  const panel = document.createElement("div");
  panel.id = "farmrpg-account-sync-pill";
  panel.innerHTML = '<i></i><span><b>Account sync</b><small>Waiting for page</small></span><button type="button" title="Capture this page now">Sync</button>';
  document.documentElement.appendChild(panel);
  const note = panel.querySelector("small");

  function setStatus(text, mode) {
    note.textContent = text;
    panel.dataset.state = mode || "";
  }
  function capture(reason) {
    clearTimeout(timer);
    timer = setTimeout(() => {
      if (typeof globalThis.__farmRpgCaptureNow !== "function") return setStatus("Collector unavailable", "error");
      setStatus("Reading this page…", "busy");
      globalThis.__farmRpgCaptureNow();
    // Farm RPG swaps the page body after the hash changes. Capturing too soon
    // records the navigation shell rather than the mastery rows.
    }, reason === "manual" ? 350 : 2500);
  }
  function routeCheck() {
    const route = location.href;
    if (route !== lastRoute) { lastRoute = route; capture("route"); }
  }

  panel.querySelector("button").addEventListener("click", () => capture("manual"));
  window.addEventListener("hashchange", routeCheck);
  window.addEventListener("popstate", routeCheck);
  window.addEventListener("pageshow", routeCheck);
  window.addEventListener("farmrpg-account-captured", (event) => {
    const result = event.detail || {};
    const detail = result.pageType === "mastery" && Number.isFinite(result.rowCount)
      ? ` (${result.rowCount} rows)`
      : "";
    setStatus(result.ok === false ? (result.error || "Could not sync") : ((result.pageType || "Page") + detail + " saved locally"), result.ok === false ? "error" : "ok");
  });
  window.addEventListener("farmrpg-account-capture-error", (event) => setStatus(event.detail || "Could not sync", "error"));
  chrome.runtime.onMessage.addListener((message, _sender, reply) => {
    if (message && message.type === "farmrpg-capture-now") { capture("manual"); reply({ ok: true }); }
  });
  setInterval(() => { if (!document.hidden) capture("periodic"); }, 90000);
  setInterval(routeCheck, 1200);
  routeCheck();
})();
