/* Farm RPG Field Planner — interface, strategy routing, and player profile. */
(function () {
  const D = window.FRPG_DATA;
  const E = window.Engine;
  const BASE_EFFECTS = window.FRPG_EFFECTS.effects;
  const BASE_CONSTS = window.FRPG_CONSTANTS;
  const P = window.FRPG_PROGRESSION || { items: {}, routeRules: {}, locationNotes: {}, _meta: {} };
  const K = window.FRPG_KNOWLEDGE || { meta: { counts: {}, sourceStatus: {} }, rules: [], meals: [], perks: [], conflicts: [] };
  const PERSONAL = window.FRPG_PERSONAL_TOWER || { startFloor: 0, goalFloor: 340, masteries: {} };
  const TOWER_FLOORS = window.FRPG_TOWER_FLOORS || { floors: [] };
  const index = E.buildIndex(D);
  // Shared so the gather lists can say where an item comes from without
  // building a second copy of this index.
  window.FRPG_INDEX = index;
  const EVENT_LOCATIONS = new Set(["Haunted House", "Santa's Workshop", "Apple Bobbing"]);
  const EXACT_AP_RATES = {
    "Mount Banon": {
      "Coal": { value: 101.93, unit: "drops/AP" },
      "Iron": { value: 101.90, unit: "drops/AP" },
      "Unpolished Shimmer Stone": { value: 101.89, unit: "drops/AP" },
      "Stone": { value: 101.88, unit: "drops/AP" },
      "Unpolished Emerald": { value: 45.78, unit: "drops/AP" },
      "Carbon Sphere": { value: 45.73, unit: "drops/AP" },
      "Magna Quartz": { value: 2.36, unit: "AP/drop" },
      "Gold Feather": { value: 6.73, unit: "AP/drop" },
      "Bacon": { value: 9.39, unit: "AP/drop" },
      "Small Chest 02": { value: 9.50, unit: "AP/drop" },
      "Runestone 19": { value: 10.86, unit: "AP/drop" },
      "Dragon Skull": { value: 47.07, unit: "AP/drop" },
    },
  };
  const $ = (id) => document.getElementById(id);
  const esc = (value) => String(value ?? "").replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  })[c]);

  const fmt = (number) => {
    if (number == null || !isFinite(number)) return "—";
    const n = Number(number);
    const abs = Math.abs(n);
    const compact = (divisor, suffix) => `${Math.round((n / divisor) * 100) / 100}${suffix}`;
    if (abs >= 1e12) return compact(1e12, "t");
    if (abs >= 1e9) return compact(1e9, "b");
    if (abs >= 1e6) return compact(1e6, "m");
    if (abs >= 1e3) return compact(1e3, "k");
    if (abs >= 100) return Math.round(n).toLocaleString("en-US");
    return String(Math.round(n * 100) / 100);
  };
  const clean = (number) => String(Math.round(Number(number) * 10000) / 10000);
  // Counts in player-facing sentences need agreement — "1 inputs" shipped once.
  const plural = (count, one, many) => `${fmt(count)} ${Number(count) === 1 ? one : many}`;
  // Filled in on every render; treeHtml reads it to label each leaf's real route.
  let leafRoutes = new Map();
  const capitalise = (text) => String(text || "").replace(/^./, (c) => c.toUpperCase());
  const ASSUMPTION_LABELS = {
    crop_qf_is_reduction: "Crop growth time saved by perks",
    crop_dod_base_cut: "Extra crop time saved by Diary of O'Dynn",
    craft_cost_cap: "Most the Workshop silver cost can be cut by",
    net_fn_base_catch: "Items per Fishing Net",
    net_ln_base_catch: "Items per Large Net",
    cider_base_rolls: "Item rolls per Apple Cider",
    lemonade_base_items: "Items per Lemonade",
    ap_base_items: "Items per Arnold Palmer",
    oj_stamina: "Stamina restored by one Orange Juice",
    quandary_bonus: "Extra output from Quandary Chowder",
    neigh_stamina_save: "Stamina saved by Neigh",
    sea_pincher_bonus: "Net boost from Sea Pincher Special",
    hickory_tick_bonus: "Sawmill boost per Hickory Omelette tick",
    acorn_pie_actions: "Actions one Acorn Pie lasts",
    explore_base_stamina: "Stamina per explore, before any perks",
    explore_stamina_measured: "Stamina you really spend, as a fraction of normal (0 = use perks)",
    plot_yield_default: "Crops harvested per seed planted",
    rate_adjust_global: "Adjustment to the community drop rates",
  };
  const FRPG_BUILD = "2026-10-08.20";
  const itemByName = (name) => index.itemsById.get(index.idByName.get(name.toLowerCase()));
  const ART = window.FRPG_ITEM_ART_HELPER;
  // Items the game has but this planner has no artwork for still need a tile.
  // A bare "?" reads as a broken image, so fall back to the item's initial.
  const artInitial = (item, fallbackName) => {
    const name = String((item && item.name) || fallbackName || "").trim();
    return name ? name[0].toUpperCase() : "·";
  };
  // Every tile size declared its image as 48x48 regardless of the class it was
  // going into, so a 23px tree tile and a 78px goal tile both claimed 48px.
  // That is what made the art jump around and sit wrong. Declare the real box.
  const ART_PX = { "": 42, "small": 30, "goal-art": 78, "table-art": 38, "tree-art": 23, "meal-art": 52, "drop-art": 32, "tower-art": 50, "haul-art": 26, "meal-chip-art": 24 };
  const artPx = (cls) => {
    for (const key of String(cls || "").split(/\s+/)) {
      if (key && ART_PX[key]) return ART_PX[key];
    }
    return ART_PX[""];
  };
  // fallbackImg lets a data file that carries its own artwork — the Tower's
  // wiki images, say — still draw when the item is not in the shared art map.
  // Without it that artwork is silently dropped and the tile shows an initial.
  // Farm RPG prints a description under each item name, and older captures
  // stored those as rows of their own ("A blinger for your finger", "Adds 100
  // Stamina"). gather-model.js filters them for the gather lists; anything
  // rendering capture data needs the same guard or they surface here instead.
  const isRealItem = (name) => {
    const text = String(name || "").trim();
    if (!text) return false;
    if (ART && ART.isCurrency && ART.isCurrency(text)) return true;
    if (ART && ART.isKnownItem) return ART.isKnownItem(text);
    return true;
  };

  const itemImg = (item, cls, fallbackName, fallbackImg) => {
    const px = artPx(cls);
    // The item's own name wins: fallbackName is for when there is no item at
    // all. Reading it the other way round made the Setup cards look up their
    // building ("Iron Depot") instead of the item they produce ("Iron").
    const name = (item && item.name) || fallbackName || "";
    const src = (ART ? ART.urlFor(name) : "") || fallbackImg || "";
    return src
      ? `<span class="item-art ${cls || ""}"><img loading="lazy" width="${px}" height="${px}" referrerpolicy="no-referrer" src="${esc(src)}" alt="${esc(name)}"></span>`
      : `<span class="item-art missing-art ${cls || ""}" aria-hidden="true">${esc(artInitial(item, fallbackName))}</span>`;
  };
  const read = (key, fallback) => {
    try {
      const raw = localStorage.getItem(key);
      return raw == null ? fallback : JSON.parse(raw);
    } catch (_) {
      return fallback;
    }
  };

  const allEffectIds = BASE_EFFECTS.map((effect) => effect.id);
  // Skill perks bought one tier at a time. Values are the game's own perk text
  // from the owner's capture (raw/account-captures/live-2026-10-05.json).
  // All three add up, tier on tier: Wanderer 4+7+9+13 = 33 (the workbook's
  // x0.67); Artisan and Negotiator 5+10+15+20 = 50. Negotiator was counted as
  // its top tier only (20%) until the owner confirmed it stacks, 2026-10-08.
  const PERK_TIERS = {
    artisan: { steps: [0.05, 0.10, 0.15, 0.20], stack: true, text: (p) => `Workshop silver cost ${p}% lower.` },
    negotiator: { steps: [0.05, 0.10, 0.15, 0.20], stack: true, text: (p) => `Items sell for ${p}% more silver.` },
    wanderer: { steps: [0.04, 0.07, 0.09, 0.13], stack: true, text: (p) => `${p}% of explores cost no stamina.` },
  };
  const TIER_NAMES = ["Off", "I", "II", "III", "IV"];
  function tierValue(id, level) {
    const tier = PERK_TIERS[id];
    if (!tier || level <= 0) return 0;
    const steps = tier.steps.slice(0, level);
    return tier.stack ? steps.reduce((sum, v) => sum + v, 0) : steps[steps.length - 1];
  }
  // A perk that is on with no tier saved is all four - how it was stored
  // before tiers could be picked.
  function tierLevel(id) {
    if (!state.enabled.has(id)) return 0;
    const saved = Number(state.perkTiers[id]);
    return saved >= 1 && saved <= 4 ? saved : 4;
  }
  // The perks are not items, so most have no picture of their own. Artifacts
  // do; the rest show the thing they work on.
  const PERK_ART = {
    artisan: "Hammer", toolbox: "Wrench", rs1: "Wooden Box", rs2: "Wooden Box",
    fert: "Treasure Chest", negotiator: "Treasure Chest", lemon_squeezer: "Lemonade",
    cinnamon: "Apple Cider", reinforced_netting: "Large Net", iron_depot: "Iron",
  };
  const perkArt = (row) => {
    const name = PERK_ART[row.key] || row.name;
    if (row.key === "wanderer") return `<span class="item-art perk-art"><img loading="lazy" width="32" height="32" src="assets/locations/explore-forest.png?v=20260905-102" alt=""></span>`;
    return itemImg(itemByName(name), "perk-art", name);
  };
  const INFRA_DEFAULTS = {
    sawmillWood: false,
    sawmillBoard: false,
    quarryStone: false,
    quarryCoal: false,
    woodHour: 0,
    boardHour: 0,
    stoneTen: 0,
    coalHour: 0,
    forgeSteel: false,
    forgeWire: false,
    hayStraw: false,
    strawTen: 0,
    hayMake: {},
    steelHour: 0,
    wireHour: 0,
  };
  const MEALS = [
    { id: "neigh", name: "Neigh", area: "Exploring economy", effect: "Cider uses 20% less stamina", calc: "Same number of Ciders, less stamina." },
    { id: "quandary", name: "Quandary Chowder", area: "Exploring economy", effect: "+10% Lemonade / AP output", calc: "Fewer Lemonades or Arnold Palmers for the same haul." },
    { id: "cabbage", name: "Cabbage Stew", area: "Bulk actions", effect: "Use 5 Ciders per click", calc: "Saves clicks only - it does not change how many you need." },
    { id: "lemoncream", name: "Lemon Cream Pie", area: "Bulk actions", effect: "Use 5 AP per click", calc: "Saves clicks only - it does not change how many you need." },
    { id: "hickory", name: "Hickory Omelette", area: "Farm production", effect: "+20% Sawmill every 10 min for 1 hour", calc: "Six extra 20% collections during that hour." },
    { id: "seapincher", name: "Sea Pincher Special", area: "Fishing economy", effect: "Nets and Large Nets are more effective", calc: "Counted as +10% catch - a community estimate." },
    { id: "shrimp", name: "Shrimp-a-Plenty", area: "Selling", effect: "+10% silver at Market for 5 minutes", calc: "Counted in every sell value." },
    { id: "mushroom", name: "Mushroom Stew", area: "Mastery", effect: "+10% Mastery for 5 minutes", calc: "Each item counts 1.1x toward a mastery, so a 1m Mega Mastery lands at about 909.09k items." },
    { id: "crunchy", name: "Crunchy Omelette", area: "Farm production", effect: "+50% items when collecting from Pets for 2 minutes", calc: "Pets only - it does not change exploring or fishing." },
  ];
  const MEAL_DEFAULTS = Object.fromEntries(MEALS.map((meal) => [meal.id, false]));

  const state = {
    itemId: null,
    qty: 1000000,
    owned: read("frpg_owned", {}),
    // Nothing is assumed: each player ticks the perks they actually own.
    enabled: new Set(read("frpg_effects_v2", [])),
    overrides: read("frpg_assumptions", {}),
    infra: Object.assign({}, INFRA_DEFAULTS, read("frpg_infra_v2", {})),
    // Acorn Pie was taken out (2026-10-08): its Hide was never measured, so
    // it could not change a number. Only meals still listed are kept.
    meals: Object.assign({}, MEAL_DEFAULTS, Object.fromEntries(Object.entries(read("frpg_meals_v2", {})).filter(([id]) => id in MEAL_DEFAULTS))),
    sourceChoices: read("frpg_sources_v2", {}),
    farmLocations: read("frpg_farm_locations_v1", {}),
    fishMethods: read("frpg_fish_methods_v1", {}),
    drinkChoices: read("frpg_drink_choices_v1", {}),
    buyRates: read("frpg_buy_rates_v1", {}),
    mealStripHidden: read("frpg_meal_strip_hidden_v1", false),
    includeEvents: read("frpg_include_events_v1", false) === true,
    drinkPath: read("frpg_drink_path_v1", "auto"),
    makeChoices: read("frpg_make_v2", {}),
    account: read("frpg_account_snapshot_v1", null),
    perkTiers: read("frpg_perk_tiers_v1", {}),
    acornTests: read("frpg_acorn_tests_v2", []),
    towerStart: Number(read("frpg_tower_start_v1", PERSONAL.startFloor || 1)),
    // save() wrote the start floor on every save, so the 277 from a first visit
    // stuck for good. Only a floor the player typed in is honoured now.
    towerStartChosen: read("frpg_tower_start_chosen_v1", false) === true,
    towerShowDone: read("frpg_tower_show_done_v1", false) === true,
    extensionConnectedAt: null,
    showCovered: false,
    treeOpen: true,
    lastPlan: null,
    decisionActions: new Map(),
  };

  const el = {
    search: $("search"), qty: $("qty"), suggest: $("suggest"), result: $("result"),
    empty: $("empty"), error: $("error"), ingBody: document.querySelector("#ingTable tbody"),
    tree: $("tree"), makeBuy: $("makeBuy"), covered: $("coveredStrip"),
  };

  function constants() {
    const copy = JSON.parse(JSON.stringify(BASE_CONSTS));
    for (const [key, value] of Object.entries(state.overrides)) {
      if (copy[key] && typeof copy[key].v === "number") copy[key].v = Number(value);
    }
    return copy;
  }
  function c(key, fallback) {
    const value = constants()[key];
    return value && value.v != null ? Number(value.v) : fallback;
  }
  function locationEffectiveness(location) {
    const effort = read("frpg_location_effort_v1", {});
    const saved = effort && effort[`explore:${location}`];
    const value = Number(saved && typeof saved === "object" ? saved.stamina : saved);
    return value > 0 ? value : 0;
  }
  // One store for effectiveness: Places, Trips and Calculate all write here.
  function setLocationEffectiveness(location, value) {
    if (window.FRPG_PLACES && window.FRPG_PLACES.setEffectiveness) return window.FRPG_PLACES.setEffectiveness(location, value);
    const effort = read("frpg_location_effort_v1", {}) || {};
    const v = Math.max(0, Number(value) || 0);
    if (v > 0) effort[`explore:${location}`] = { stamina: v }; else delete effort[`explore:${location}`];
    localStorage.setItem("frpg_location_effort_v1", JSON.stringify(effort));
  }
  function mods() {
    const chosen = BASE_EFFECTS.filter((effect) => state.enabled.has(effect.id))
      .map((effect) => (PERK_TIERS[effect.id] ? { ...effect, value: tierValue(effect.id, tierLevel(effect.id)) } : effect));
    const base = E.computeMods(chosen, constants());
    if (state.meals.shrimp) base.saleMult += 0.1;
    // The perk list above knows about Wanderer and little else, so it can badly
    // overstate stamina for an endgame account. If the player has told us what
    // they actually spend, that wins.
    const measured = Number(c("explore_stamina_measured", 0));
    if (measured > 0) base.exploreStaminaPer = c("explore_base_stamina", 1) * measured;
    return base;
  }
  // Places reads the same resolved perk numbers, so ticking Lemon Squeezer
  // in Setup changes what an Arnold Palmer is worth there too.
  window.FRPG_MODS = mods;
  // Places shows the same meal switches. One store, so the two pages cannot
  // disagree — writing straight to localStorage would leave state.meals here
  // stale until a reload.
  window.FRPG_MEALS = {
    list: () => MEALS.map((meal) => ({ id: meal.id, name: meal.name, effect: meal.effect })),
    get: (id) => !!state.meals[id],
    set: (id, on) => {
      if (!(id in state.meals)) return false;
      state.meals[id] = !!on;
      save();
      if (document.getElementById("setup").classList.contains("active")) renderSetup();
      render();
      return true;
    },
  };

  function save() {
    localStorage.setItem("frpg_owned", JSON.stringify(state.owned));
    localStorage.setItem("frpg_effects_v2", JSON.stringify([...state.enabled]));
    localStorage.setItem("frpg_perk_tiers_v1", JSON.stringify(state.perkTiers));
    localStorage.setItem("frpg_assumptions", JSON.stringify(state.overrides));
    localStorage.setItem("frpg_infra_v2", JSON.stringify(state.infra));
    localStorage.setItem("frpg_meals_v2", JSON.stringify(state.meals));
    localStorage.setItem("frpg_sources_v2", JSON.stringify(state.sourceChoices));
    localStorage.setItem("frpg_farm_locations_v1", JSON.stringify(state.farmLocations));
    localStorage.setItem("frpg_fish_methods_v1", JSON.stringify(state.fishMethods));
    localStorage.setItem("frpg_drink_choices_v1", JSON.stringify(state.drinkChoices));
    localStorage.setItem("frpg_buy_rates_v1", JSON.stringify(state.buyRates));
    localStorage.setItem("frpg_meal_strip_hidden_v1", JSON.stringify(state.mealStripHidden));
    localStorage.setItem("frpg_include_events_v1", JSON.stringify(state.includeEvents));
    localStorage.setItem("frpg_drink_path_v1", JSON.stringify(state.drinkPath));
    localStorage.setItem("frpg_make_v2", JSON.stringify(state.makeChoices));
    localStorage.setItem("frpg_acorn_tests_v2", JSON.stringify(state.acornTests));
    localStorage.setItem("frpg_tower_start_v1", JSON.stringify(state.towerStart));
    localStorage.setItem("frpg_tower_start_chosen_v1", JSON.stringify(state.towerStartChosen));
    localStorage.setItem("frpg_tower_show_done_v1", JSON.stringify(state.towerShowDone));
    try {
      if (state.account) localStorage.setItem("frpg_account_snapshot_v1", JSON.stringify(state.account));
      else localStorage.removeItem("frpg_account_snapshot_v1");
    } catch (_) {
      localStorage.removeItem("frpg_account_snapshot_v1");
    }
  }

  // Every tab change replaced the hash instead of pushing it, so the browser
  // kept no history and Back left the site entirely. Tab changes push; going
  // Back or Forward calls this again with fromHistory set, which must not
  // push another entry or Back would never escape.
  function showTab(id, fromHistory) {
    document.querySelectorAll(".view").forEach((view) => view.classList.toggle("active", view.id === id));
    document.querySelectorAll(".tab").forEach((tab) => {
      const selected = tab.dataset.tab === id;
      tab.classList.toggle("active", selected);
      // These are page links in a nav, not an ARIA tablist, so the current one
      // is marked with aria-current; aria-selected is not valid on a button.
      if (selected) tab.setAttribute("aria-current", "page");
      else tab.removeAttribute("aria-current");
    });
    // On a phone the tabs are a sideways strip. Keep the one you are on in
    // view instead of leaving it scrolled off the edge.
    const activeTab = document.querySelector(`.tab[data-tab="${id}"]`);
    const tabRow = activeTab && activeTab.parentElement;
    if (tabRow && tabRow.scrollWidth > tabRow.clientWidth) activeTab.scrollIntoView({ block: "nearest", inline: "nearest" });
    // Each view names itself in the browser tab and in history, like a page.
    const viewName = id === "home" ? "" : ((activeTab && activeTab.firstChild && activeTab.firstChild.textContent.trim())
      || ((document.querySelector(`#${id} h1`) || {}).textContent || "").trim());
    document.title = viewName ? `${viewName} — Farm RPG Calculator` : "Farm RPG Calculator";
    if (id === "planner" && !state.itemId) renderEmptySuggestions();
    if (id === "planner" && state.itemId) render();
    if (id === "setup" || id === "fieldlab") renderSetup();
    if (id === "account") renderAccount();
    if (id === "tower") renderTower();
    if (id === "home") renderHome();
    if (id === "places" && window.FRPG_renderPlaces) window.FRPG_renderPlaces();
    if (id === "trips" && window.FRPG_renderTrips) window.FRPG_renderTrips();
    if (history && history.pushState) {
      // Keep any sub-path the view owns, so returning to Items does not
      // throw away which item was open.
      const current = location.hash.replace(/^#/, "");
      const target = "#" + (current.split("/")[0] === id && current.includes("/") ? current : id);
      if (fromHistory) history.replaceState(null, "", target);
      else if (location.hash !== target) history.pushState(null, "", target);
    }
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
  document.querySelectorAll(".tab").forEach((tab) => { tab.onclick = () => showTab(tab.dataset.tab); });
  // The skip link must move focus without touching the hash: the hash is the
  // router here, and "#main" is not a view, so following it would throw the
  // player back to Home from whatever tab they were on.
  const skipLink = document.querySelector(".skip-link");
  if (skipLink) skipLink.addEventListener("click", (event) => {
    event.preventDefault();
    const main = document.querySelector("main");
    if (main) main.focus();
  });
  document.addEventListener("click", (event) => {
    const control = event.target.closest("[data-open-view]");
    if (!control || control.dataset.openViewBound === "1") return;
    event.preventDefault();
    showTab(control.dataset.openView);
  });
  document.querySelectorAll("[data-open-view]").forEach((control) => {
    control.dataset.openViewBound = "1";
    control.onclick = (event) => { event.preventDefault(); showTab(control.dataset.openView); };
  });

  function searchItems(query) {
    const q = query.trim().toLowerCase();
    if (q.length < 2) return [];
    return D.items.items.filter((item) => item.active && item.name.toLowerCase().includes(q)).sort((a, b) => {
      const A = a.name.toLowerCase(), B = b.name.toLowerCase();
      return Number(B.startsWith(q)) - Number(A.startsWith(q)) || A.localeCompare(B);
    }).slice(0, 14);
  }
  function suggestions(list) {
    if (!list.length) {
      el.suggest.classList.add("hidden");
      return;
    }
    el.suggest.innerHTML = list.map((item) => `<div class="sg" data-id="${item.id}">${itemImg(item, "small")}<span class="sg-name">${esc(item.name)}</span><span class="sub">${item.craftPrice != null ? "craft" : item.growMin > 0 ? "crop" : item.cookLevel > 0 ? "cook" : item.type || "item"}</span></div>`).join("");
    el.suggest.classList.remove("hidden");
    el.suggest.querySelectorAll(".sg").forEach((row) => {
      row.onmousedown = (event) => { event.preventDefault(); pick(Number(row.dataset.id)); };
    });
  }
  function pick(id) {
    state.itemId = id;
    el.search.value = index.itemsById.get(id).name;
    el.suggest.classList.add("hidden");
    localStorage.setItem("frpg_last", String(id));
    render();
  }

  // Cross-page bridge: lets other loaded scripts (Quests, New items) open an
  // item directly in the calculator without duplicating item lookup/route
  // logic. Returns true if the item was found and opened.
  window.FRPG_openItem = function (name, qty) {
    const id = index.idByName.get(String(name || "").trim().toLowerCase());
    if (!id) return false;
    const parsedQty = Number(qty);
    if (Number.isFinite(parsedQty) && parsedQty > 0) {
      state.qty = Math.round(parsedQty);
      el.qty.value = state.qty.toLocaleString("en-US");
    }
    pick(id);
    showTab("planner");
    return true;
  };

  // Where you actually stand, on the first page you see: the floor you are
  // climbing, the quest step you are on, and how much of that step's gathering
  // also finishes a Tower mastery. All of it is elsewhere in the app already —
  // the point is not having to go and look.
  function renderStanding() {
    const host = $("homeStanding");
    if (!host) return;
    const gather = window.FRPG_GATHER;
    const bits = [];

    // No farm loaded and no floor typed in: a "next floor" here would be a
    // guess dressed up as the player's own progress.
    if (window.FRPG_ACCOUNT_MODE === "empty" && !state.account && !state.towerStartChosen) {
      bits.push(`<a href="#account" data-open-view="account"><span>Your farm</span><strong>Not connected</strong><small>Connect it to see your Tower floor and quest step</small></a>`);
    }
    const needs = window.FRPG_ACCOUNT_MODE === "empty" && !state.account && !state.towerStartChosen ? [] : (window.FRPG_TOWER_NEEDS || []);
    const nextFloor = needs.filter((row) => !row.complete).sort((a, b) => a.floor - b.floor)[0];
    if (nextFloor) {
      const left = needs.filter((row) => row.floor === nextFloor.floor && !row.complete).length;
      bits.push(`<a href="#tower" data-open-view="tower"><span>Next floor</span><strong>T${nextFloor.floor}</strong><small>${left} ${left === 1 ? "mastery" : "masteries"} to go</small></a>`);
    }

    if (gather && typeof gather.plan === "function") {
      const plan = gather.plan();
      if (plan.next) {
        const short = plan.nextRows.filter((row) => row.short > 0).length;
        bits.push(`<a href="#inventory" data-open-view="inventory"><span>Current step</span><strong>${esc(plan.next.title)}</strong><small>${short} item${short === 1 ? "" : "s"} still short</small></a>`);
        if (typeof gather.towerOverlap === "function") {
          const both = gather.towerOverlap(plan.wholeRows.filter((row) => row.short > 0)).length;
          if (both) bits.push(`<a href="#inventory" data-open-view="inventory"><span>Counts twice</span><strong>${fmt(both)}</strong><small>items feed this line and a Tower mastery</small></a>`);
        }
      }
    }

    // Silver, gold and stamina, as of the last capture that read them. Farm
    // RPG prints silver and gold in its top bar on every page, and stamina on
    // the pages that spend it.
    const balances = (state.account && state.account.balances) || null;
    const money = [];
    if (balances) {
      const amount = (v) => { const raw = v && typeof v === "object" ? v.value : v; if (raw == null || raw === "") return null; const n = Number(raw); return Number.isFinite(n) ? n : null; };
      const silver = amount(balances.silver), gold = amount(balances.gold);
      const now = amount(balances.staminaCurrent), max = amount(balances.staminaMaximum);
      const farmhouse = (state.account.infrastructure || {}).farmhouse || {};
      const rest = amount(farmhouse.restStamina);
      // Every page carries silver and gold, so they are as fresh as the newest
      // capture of any page — not the snapshot's generatedAt, which lags.
      const newest = ((state.account.captures || []).map((c) => Date.parse(c.capturedAt || "")).filter(Number.isFinite).sort((x, y) => y - x)[0]) || Date.parse(state.account.generatedAt || "");
      const when = Number.isFinite(newest) ? new Date(newest).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }) : "";
      const tile = (label, value, note) => `<div class="standing-balance"><span>${label}</span><strong>${value}</strong><small>${note}</small></div>`;
      money.push(tile("Silver", silver != null ? fmt(silver) : "—", silver != null ? `as of ${when}` : "capture any Farm RPG page"));
      money.push(tile("Gold", gold != null ? gold.toLocaleString("en-US") : "—", gold != null ? `as of ${when}` : "capture any Farm RPG page"));
      money.push(tile("Stamina", now != null ? (max != null ? `${fmt(now)} / ${fmt(max)}` : fmt(now)) : (max != null ? `max ${fmt(max)}` : "—"),
        (now != null ? `as of ${when}` : max != null ? "capture an explore page for what you have now" : "capture an explore page")
          + (rest != null ? ` · resting gives +${fmt(rest)}` : "")));
    }

    host.hidden = bits.length === 0;
    host.innerHTML = bits.join("");
    let wallet = $("homeWallet");
    if (!wallet && money.length) {
      wallet = document.createElement("div");
      wallet.id = "homeWallet";
      wallet.className = "home-standing home-wallet";
      host.insertAdjacentElement("afterend", wallet);
    }
    if (wallet) { wallet.hidden = money.length === 0; wallet.innerHTML = money.join(""); }
  }

  function renderHome() {
    const item = state.itemId ? index.itemsById.get(state.itemId) : null;
    $("homeRecent").innerHTML = item
      ? `<button class="recent-button" data-home-recent><span>Last calculation</span><strong>${itemImg(item, "small")}${esc(item.name)} × ${fmt(state.qty)}</strong><b>Continue →</b></button>`
      : "";
    const recent = document.querySelector("[data-home-recent]");
    if (recent) recent.onclick = () => showTab("planner");
    renderStanding();
  }

  $("itemOptions").innerHTML = D.items.items.filter((item) => item.active).map((item) => `<option value="${esc(item.name)}"></option>`).join("");
  $("homeGoal").onsubmit = (event) => {
    event.preventDefault();
    const query = $("homeSearch").value.trim().toLowerCase();
    const exactId = index.idByName.get(query);
    const candidate = exactId ? index.itemsById.get(exactId) : searchItems(query)[0];
    if (!candidate) {
      $("homeSearch").setCustomValidity("Choose an item from the Farm RPG item list.");
      $("homeSearch").reportValidity();
      return;
    }
    $("homeSearch").setCustomValidity("");
    const qty = parseQty($("homeQty").value);
    if (!qty) return;
    state.qty = qty;
    el.qty.value = String(qty);
    pick(candidate.id);
    showTab("planner");
  };
  el.search.oninput = () => suggestions(searchItems(el.search.value));
  el.search.onblur = () => setTimeout(() => el.suggest.classList.add("hidden"), 120);
  el.search.onkeydown = (event) => {
    if (event.key === "Enter") {
      const first = el.suggest.querySelector(".sg");
      if (first) pick(Number(first.dataset.id));
    }
  };
  el.qty.oninput = () => { state.qty = parseQty(el.qty.value); render(); };
  el.qty.onblur = () => { if (state.qty > 0) el.qty.value = state.qty.toLocaleString("en-US"); };
  $("clearOwned").onclick = () => { state.owned = {}; save(); render(); };
  $("collapseTree").onclick = () => {
    state.treeOpen = !state.treeOpen;
    el.tree.querySelectorAll("details").forEach((detail) => { detail.open = state.treeOpen; });
    $("collapseTree").textContent = state.treeOpen ? "Collapse all" : "Expand all";
  };
  $("toggleCovered").onchange = (event) => { state.showCovered = event.target.checked; render(); };

  // Production is collected in ticks, and anything over the inventory cap at
  // the moment you collect is simply gone. A Sawmill making 22,000 Boards per
  // 10 minutes into a 15,870 cap delivers 15,870 — the other 6,130 never
  // existed. So past a point the cap, not the building, is the limit.
  function afterCap(perHour, ticksPerHour) {
    const cap = Number(state.infra.inventoryCap || 0);
    if (!(cap > 0) || !(perHour > 0) || !(ticksPerHour > 0)) return { rate: perHour, voided: 0 };
    const perTick = perHour / ticksPerHour;
    const kept = Math.min(perTick, cap);
    return { rate: kept * ticksPerHour, voided: (perTick - kept) * ticksPerHour };
  }
  function cappedDetail(perHour, ticksPerHour, label) {
    const capped = afterCap(perHour, ticksPerHour);
    if (!capped.rate) return { rate: 0, detail: "Covered; enter your rate in Setup" };
    return {
      rate: capped.rate,
      detail: capped.voided > 0
        ? `${fmt(capped.rate)}/hr reaches you — ${fmt(capped.voided)}/hr is over your inventory cap and lost`
        : `${fmt(capped.rate)}/hr ${label}`,
    };
  }
  function infraFor(item, need, m) {
    if (!item) return null;
    const name = item.name.toLowerCase();
    if ((name === "iron" || name === "nails") && m.ironDepot) {
      const silver = (item.buy || 0) * need;
      return { kind: "Iron Depot", detail: `Auto-filled for ${fmt(silver)} silver`, hours: null };
    }
    if ((name === "wood" && state.infra.sawmillWood) || (name === "board" && state.infra.sawmillBoard)) {
      // Hickory turns one hourly collection into six. That is worth far more
      // than the 2.2x it looks like, because a single hourly drop large enough
      // to overflow the cap loses the overflow every time.
      const ticks = state.meals.hickory ? 6 : 1;
      const multiplier = state.meals.hickory ? 1 + 6 * c("hickory_tick_bonus", 0.2) : 1;
      const raw = Number(state.infra[name === "wood" ? "woodHour" : "boardHour"] || 0) * multiplier;
      const out = cappedDetail(raw, ticks, "useful output");
      return { kind: "Sawmill", detail: out.detail, hours: out.rate ? need / out.rate : null };
    }
    // The Hay Field drops Straw every 10 minutes, like the Quarry drops Stone.
    // Covering Straw is what covers Twine, Rope and everything else built on it.
    if (name === "straw" && state.infra.hayStraw) {
      const out = cappedDetail(Number(state.infra.strawTen || 0) * 6, 6, "from 10-minute ticks");
      return { kind: "Hay Field", detail: out.detail, hours: out.rate ? need / out.rate : null };
    }
    if (name === "stone" && state.infra.quarryStone) {
      const out = cappedDetail(Number(state.infra.stoneTen || 0) * 6, 6, "from 10-minute ticks");
      return { kind: "Quarry", detail: out.detail, hours: out.rate ? need / out.rate : null };
    }
    // Steel and Steel Wire come out of the same building, and the owner's own
    // measurement is that Wire runs at a third of Steel — 1,500/hr while Steel
    // was 4,500. Both rates stay editable because that ratio is one player's
    // observation, not a stated rule.
    if (name === "steel" && state.infra.forgeSteel) {
      const rate = Number(state.infra.steelHour || 0);
      return { kind: "Steel production", detail: rate ? `${fmt(rate)}/hr` : "Covered; enter your rate in Setup", hours: rate ? need / rate : null };
    }
    if (name === "steel wire" && state.infra.forgeWire) {
      const rate = Number(state.infra.wireHour || 0);
      return { kind: "Steel Wire production", detail: rate ? `${fmt(rate)}/hr` : "Covered; enter your rate in Setup", hours: rate ? need / rate : null };
    }
    if (name === "coal" && state.infra.quarryCoal) {
      const rate = Number(state.infra.coalHour || 0);
      return { kind: "Quarry coal", detail: rate ? `${fmt(rate)}/hr measured average` : "Marked covered without a measured rate", hours: rate ? need / rate : null };
    }
    return null;
  }

  function quoteText(quote) {
    if (!quote || !quote.best) return "No trade quote";
    const best = quote.best;
    const unit = best.currency === "gold" ? "gold" : best.currency.toUpperCase();
    const rate = best.raw || `${fmt(best.rate)} ${unit}${best.per === 1000 ? "/k" : ""}`;
    return `${rate} → ${fmt(best.amount)} ${unit}${best.goldEq != null && best.currency !== "gold" ? ` ≈ ${fmt(best.goldEq)} gold` : ""}`;
  }
  function goldEach(itemName) {
    const market = index.marketByName.get(itemName.toLowerCase());
    if (!market || !market.gold) return null;
    return market.gold.mid / E.pricePer((market.raw || {}).gold);
  }

  function acornPlan(need) {
    if (!state.meals.acorn || !state.acornTests.length || need <= 0) return null;
    const plans = [];
    for (const test of state.acornTests) {
      const uses = Number(test.uses), hides = Number(test.hides);
      if (!(uses > 0 && hides > 0)) continue;
      const requiredUses = need * uses / hides;
      const bulkMeal = test.method === "ap" && state.meals.lemoncream ? "Lemon Cream Pie"
        : test.method === "cider" && state.meals.cabbage ? "Cabbage Stew" : null;
      const bulk = bulkMeal ? 5 : 1;
      const actions = requiredUses / bulk;
      const pies = Math.ceil(actions / c("acorn_pie_actions", 150));
      let fullRouteGoldEq = null;
      let extra = "";
      if (test.method === "ap") {
        const unit = goldEach("Arnold Palmer");
        fullRouteGoldEq = unit == null ? null : requiredUses * unit;
      } else if (test.method === "cider") {
        const ciderUnit = goldEach("Apple Cider");
        const ojUnit = E.currencyGoldEach(index, "oj");
        const stamina = requiredUses * c("cider_base_rolls", 1000) * (state.meals.neigh ? 1 - c("neigh_stamina_save", 0.2) : 1);
        const oj = stamina / c("oj_stamina", 100);
        fullRouteGoldEq = ciderUnit == null || ojUnit == null ? null : requiredUses * ciderUnit + oj * ojUnit;
        extra = ` · ${fmt(oj)} OJ-equivalent stamina`;
      } else if (test.method === "lemonade") {
        const unit = goldEach("Lemonade");
        fullRouteGoldEq = unit == null ? null : requiredUses * unit;
      } else {
        const ojUnit = E.currencyGoldEach(index, "oj");
        const stamina = requiredUses * mods().exploreStaminaPer;
        fullRouteGoldEq = ojUnit == null ? null : stamina / c("oj_stamina", 100) * ojUnit;
      }
      const pieQuote = E.marketQuote(index, "Acorn Pie", pies);
      const incrementalGoldEq = pieQuote && pieQuote.best.goldEq != null ? pieQuote.best.goldEq : null;
      plans.push({
        type: "acorn", method: test.method, location: test.location, uses: requiredUses,
        actions, pies, bulk, bulkMeal, goldEq: incrementalGoldEq, fullRouteGoldEq, extra, overlay: true,
        confidence: { label: "Your measured sample", level: 3 }, progressionScore: 20,
        reason: "Run Acorn Pie during exploration you already need; charge Hide only for the pies, not for the underlying AP/Cider twice.",
        detail: `Piggyback ${fmt(actions)} actions · ${fmt(pies)} Acorn Pies${bulkMeal ? ` · ${bulkMeal} makes 5 uses cost 1 action` : ""}${incrementalGoldEq != null ? ` ≈ ${fmt(incrementalGoldEq)} gold incremental` : ""}`,
      });
    }
    return plans.filter((plan) => plan.goldEq != null).sort((a, b) => a.goldEq - b.goldEq)[0] || plans[0] || null;
  }

  const isFish = (item) => !!item && item.type === "fish";
  // Drops per Arnold Palmer, straight from the shared workbook. Null when that
  // location/item pair was never measured — never guessed from the explore rate.
  function workbookApRate(location, itemName) {
    const table = window.FRPG_WORKBOOK_RATES && window.FRPG_WORKBOOK_RATES.exploring;
    const row = table && table[location];
    const rate = row && row[itemName];
    return rate > 0 ? rate : null;
  }
  // Drops per Large Net from the same workbook. Its fishing tables add up to
  // 500 a net: 250 base + Reinforced Netting + Trigon Knot, and no meal.
  const WORKBOOK_NET_CATCH = 500;
  function workbookLnRate(location, itemName) {
    const table = window.FRPG_WORKBOOK_RATES && window.FRPG_WORKBOOK_RATES.fishing;
    const row = table && table[location];
    const rate = row && row[itemName];
    return rate > 0 ? rate : null;
  }
  // Mines list what they turn up but carry no rates, so a mined item can say
  // where it comes from and nothing more.
  const MINES = (((window.FRPG_LOCATION_INTEL || {}).mining || {}).mines) || [];
  const mineFor = (name) => MINES.find((mine) =>
    (mine.items || []).some((entry) => String(entry).toLowerCase() === String(name).toLowerCase())) || null;
  const itemFact = (name) => P.items[name] || { questSteps: 0, questTotal: 0, usedInCrafts: 0, relevance: 0, hoard: false };
  const routeRule = (name) => P.routeRules[name] || null;

  // The questline lookup lives in quest-model.js so the Items page and this
  // page answer "still needed for quests" from the same index.
  const QUEST_MODEL = window.FRPG_QUEST_MODEL || null;
  const questNeedsFor = (name) => QUEST_MODEL ? QUEST_MODEL.needsByItem(name, state.account) : null;
  // What a quest still costs YOU: what it asks for, less what is already in
  // the barn at the last capture. Without a capture it stays the full ask.
  const heldOf = (name) => {
    const rows = (state.account && state.account.inventory) || [];
    const row = rows.find((entry) => entry && String(entry.name || "").trim().toLowerCase() === String(name).trim().toLowerCase());
    const quantity = row ? Number(row.quantity) : NaN;
    return Number.isFinite(quantity) ? quantity : null;
  };
  const QUEST_STATUS_WORD = (status) => QUEST_MODEL ? QUEST_MODEL.needStatusWord(status) : "";

  function questNeedsHtml(name) {
    const needs = questNeedsFor(name);
    if (!needs) return "";
    const shown = needs.rows.slice(0, 40);
    const more = needs.rows.length - shown.length;
    const line = (row) => {
      const word = QUEST_STATUS_WORD(row.status);
      const bits = [row.line, row.category === "event" ? "event" : "", word].filter(Boolean).join(" · ");
      return `<div class="quest-need"><b>${fmt(row.quantity)}</b><span>${esc(row.title)}<small>${esc(bits)}</small></span></div>`;
    };
    return `<details class="quest-needs"><summary>Still needed for quests — ${fmt(needs.total)} across ${plural(needs.steps, "quest", "quests")}</summary>` +
      `<div class="quest-needs-body">${shown.map(line).join("")}` +
      (more > 0 ? `<p class="quest-needs-more">And ${plural(more, "quest", "quests")} more.</p>` : "") +
      `</div></details>`;
  }
  const farmLabel = (farm) => farm.type === "fish" ? "Fish" : farm.type === "crop" ? "Grow" : farm.type === "acorn" ? "Acorn overlay" : "Explore";

  function coDropSentence(route) {
    if (!route || !route.coDrops || !route.coDrops.length) return "";
    const preview = route.coDrops.slice(0, 4).map((drop) => `${fmt(drop.expected)} ${esc(drop.name)}`).join(" · ");
    const more = Math.max(0, route.coDrops.length - 4);
    return `${preview}${more ? ` · +${more} more below` : ""}`;
  }

  function decisionLabel(value) {
    return ({ trade: "Buy/trade", farm: "Farm directly", craft: "Craft it", building: "Passive supply",
      acorn: "Acorn Pie overlay", explore: "Explore for it", fish: "Fish for it", crop: "Grow it",
      vendor: "Country Store", inventory: "Use inventory" })[value] || value;
  }

  // kind: "explore" or "fish" keeps to that one way of gathering, for an item
  // you can get both ways (Water Lily: Sinking Swamp or Forest Pond nets).
  function farmPlan(item, need, m, consts, kind) {
    // Some items technically drop somewhere but nobody sane gathers them —
    // Glass Bottle off Crystal River at ~1 per 68 casts, for instance. A rule
    // with never:"farm" keeps them out of the routing entirely.
    const noFarm = routeRule(item.name);
    if (noFarm && noFarm.never === "farm") return null;
    if (!item || need <= 0) return null;
    const sources = E.sourcesFor(index, item.id, need, m, consts);
    if (item.name === "Hide") {
      const measured = acornPlan(need);
      if (measured) return measured;
    }
    // Something you can both grow and find (Mushroom) used to stop here, so
    // its exploring places never showed. Growing is now its own choice; the
    // gathering route wins unless there is nothing to gather.
    const canGather = sources.drops.some((row) => row.explores != null) || sources.fish.some((row) => row.catches != null);
    if (sources.crop && !canGather) return kind ? null : cropPlan(item, need, sources);
    return gatherPlan(item, need, m, consts, sources, kind);
  }

  function cropPlan(item, need, sources) {
    sources = sources || E.sourcesFor(index, item.id, need, mods(), constants());
    if (!sources.crop) return null;
    return {
      type: "crop",
      plants: sources.crop.plants,
      minutes: sources.crop.minutesEach,
      goldEq: null,
      confidence: { label: "Official crop time", level: 3 },
      progressionScore: itemFact(item.name).relevance || 0,
      detail: `${fmt(sources.crop.plants)} plants · ${fmt(sources.crop.minutesEach)} min/harvest`,
    };
  }

  // Everything else a fishing run brings up, from the place's own logged
  // tables: each catch is one roll, so N catches give N / (catches per drop).
  // The fish table is per catch; the outcome table adds what is not a fish.
  function fishCoDrops(item, location, catches) {
    const place = D.sources.locations.find((loc) => loc.name === location && loc.type === "fishing");
    if (!place || !(catches > 0)) return [];
    const rows = new Map();
    for (const [name, info] of Object.entries(place.fish || {})) if (info && info.denom > 0) rows.set(name, info.denom);
    for (const [name, info] of Object.entries(place.drops || {})) if (info && info.denom > 0 && !rows.has(name)) rows.set(name, info.denom);
    rows.delete(item.name);
    return [...rows].map(([name, denom]) => ({ name, expected: catches / denom, score: 0 }))
      .filter((row) => row.expected >= 1).sort((a, b) => b.expected - a.expected).slice(0, 20);
  }

  function gatherPlan(item, need, m, consts, sources, kind) {
    const rule = routeRule(item.name);
    const dropPlans = (kind === "fish" ? [] : sources.drops).filter((row) => row.explores != null && (state.includeEvents || !EVENT_LOCATIONS.has(row.location))).map((drop) => {
      const qc = state.meals.quandary ? 1 + c("quandary_bonus", 0.1) : 1;
      const neigh = state.meals.neigh ? 1 - c("neigh_stamina_save", 0.2) : 1;
      // Places stores the effectiveness printed by Farm RPG for each location.
      // Calculate must use the same number instead of treating every Cider as
      // if it were used at effectiveness 0.
      const effectiveness = locationEffectiveness(drop.location);
      const exploresPerCider = m.drinks.ciderRolls * (1 + effectiveness / 100);
      const ciderUses = exploresPerCider > 0 ? drop.explores / exploresPerCider : null;
      const stamina = drop.explores * m.exploreStaminaPer * neigh;
      const oj = stamina / c("oj_stamina", 100);
      // Arnold Palmer is NOT exploring. Exploring spends stamina; an AP finds
      // items on its own, with its own drop rate per use. Deriving AP uses from
      // the explore count treated one as a bulk purchase of the other, which is
      // wrong. Use the workbook's measured drops-per-AP when we have it.
      // Its exploring rates are stated with Quandary Chowder on (each location's
      // table sums to 550 = 500 x 1.1), so back that out if the meal is off.
      const wbAp = workbookApRate(drop.location, item.name);
      const apUses = wbAp != null
        ? need / (wbAp * (state.meals.quandary ? 1 : 1 / (1 + c("quandary_bonus", 0.1))))
        : null;
      const ciderUnit = goldEach("Apple Cider");
      const apUnit = goldEach("Arnold Palmer");
      const ojUnit = E.currencyGoldEach(index, "oj");
      const ciderGold = ciderUnit == null || ojUnit == null ? null : ciderUses * ciderUnit + oj * ojUnit;
      const apGold = apUnit == null || apUses == null ? null : apUses * apUnit;
      // The player picks the drink. Cider spends stamina and an Arnold Palmer
      // does not, so there is no honest "cheaper" to pick for them.
      const pick = state.drinkChoices[item.id];
      const useAp = pick === "ap" ? apUses != null : false;
      const coDrops = E.coDropsFor(index, drop.location, drop.explores, item.name, P, 20);
      const prized = (P.locationNotes[drop.location] || {}).prizedCoDrops || [];
      coDrops.sort((a, b) => {
        const ai = prized.indexOf(a.name), bi = prized.indexOf(b.name);
        return (ai < 0 ? 999 : ai) - (bi < 0 ? 999 : bi) || b.score - a.score;
      });
      const coDropSellSilver = coDrops.reduce((sum, co) => {
        const coItem = itemByName(co.name);
        return sum + (coItem && coItem.sell != null ? co.expected * coItem.sell * m.saleMult : 0);
      }, 0);
      const progressionScore = coDrops.reduce((sum, co) => sum + Math.min(6, co.score), itemFact(item.name).relevance || 0);
      const preferred = !!(rule && rule.action === "farm" && (!rule.location || rule.location === drop.location));
      return {
        type: "explore",
        method: useAp ? "ap" : "cider",
        location: drop.location,
        explores: drop.explores,
        stamina,
        oj,
        ciders: ciderUses,
        effectiveness,
        aps: apUses,
        goldEq: useAp ? apGold : ciderGold,
        // Keep both sides of the drink comparison so the plan can show its
        // working. Cider looks cheaper per bottle but burns stamina, and how
        // much stamina depends on the player's own perks and meals.
        ciderGold,
        apGold,
        coDrops,
        coDropSellSilver,
        progressionScore,
        preferred,
        confidence: E.sourceConfidence(drop.src),
        reason: preferred ? rule.why : coDrops.length ? `Also advances ${coDrops.slice(0, 3).map((co) => co.name).join(", ")}` : "Fastest known direct drop",
        detail: useAp
          ? `${esc(drop.location)} · ${fmt(apUses)} AP with${state.meals.quandary ? "" : "out"} Quandary`
          : `${esc(drop.location)} · ${fmt(ciderUses)} Cider at ${fmt(effectiveness)}% effectiveness + ${fmt(oj)} OJ-equivalent stamina`,
      };
    }).sort((a, b) => a.explores - b.explores);
    const chosenLocation = state.farmLocations[item.id];
    const chosenDrop = dropPlans.find((plan) => plan.location === chosenLocation);
    if (chosenDrop) return chosenDrop;
    const fishPlans = (kind === "explore" ? [] : sources.fish).filter((row) => row.catches != null && (state.includeEvents || !EVENT_LOCATIONS.has(row.location))).sort((a, b) => a.catches - b.catches);
    const chosenFish = fishPlans.find((row) => row.location === chosenLocation);
    const buildFish = (fish) => {
      const mealBoost = state.meals.seapincher ? 1 + c("sea_pincher_bonus", 0.1) : 1;
      const lnCatch = m.nets.lnCatch * mealBoost;
      const fnCatch = m.nets.fnCatch * mealBoost;
      // Nets read the owner's sheet when it measured this fish here, the same
      // way Arnold Palmers do. It counted 500 catches a net, so it scales to
      // this account's nets, and Sea Pincher goes on top. Casting by hand has
      // no sheet rate and keeps the logged catches.
      const wbLn = workbookLnRate(fish.location, item.name);
      const perNet = (catchSize) => wbLn * (catchSize / WORKBOOK_NET_CATCH) * mealBoost;
      const largeNets = wbLn != null && m.nets.lnCatch > 0 ? need / perNet(m.nets.lnCatch)
        : lnCatch > 0 ? fish.catches / lnCatch : null;
      const fishingNets = wbLn != null && m.nets.fnCatch > 0 ? need / perNet(m.nets.fnCatch)
        : fnCatch > 0 ? fish.catches / fnCatch : null;
      // Fishing by hand is one cast at a time. How much stamina a cast costs is
      // not recorded in any local source, so the cast count is given and the
      // stamina is left blank rather than guessed.
      const method = FISH_METHODS[state.fishMethods[item.id]] ? state.fishMethods[item.id] : "large";
      const lnUnit = goldEach("Large Net");
      const fnUnit = goldEach("Fishing Net");
      const goldEq = method === "large" ? (lnUnit == null || largeNets == null ? null : largeNets * lnUnit)
        : method === "net" ? (fnUnit == null || fishingNets == null ? null : fishingNets * fnUnit)
        : null;
      const detailBy = method === "large" ? `${fmt(largeNets)} Large Nets`
        : method === "net" ? `${fmt(fishingNets)} Fishing Nets`
        : `${fmt(fish.catches)} casts by hand`;
      // 250 base + 150 Reinforced Netting + 100 Trigon Knot = 500 per Large Net,
      // which is exactly what the shared workbook quotes. Sea Pincher then adds
      // 10% on top (community estimate, sea_pincher_bonus is verified:false).
      const netNotes = [
        state.enabled.has("reinforced_ln") && "Reinforced Netting",
        state.enabled.has("trigonn") && "Trigon Knot",
        state.meals.seapincher && "Sea Pincher",
      ].filter(Boolean);
      return {
        type: "fish",
        location: fish.location,
        catches: fish.catches,
        netNotes,
        coDrops: fishCoDrops(item, fish.location, method === "large" && largeNets != null ? largeNets * lnCatch
          : method === "net" && fishingNets != null ? fishingNets * fnCatch : fish.catches),
        method,
        largeNets,
        fishingNets,
        lnCatch,
        fnCatch,
        goldEq,
        confidence: E.sourceConfidence(fish.src),
        progressionScore: itemFact(item.name).relevance || 0,
        detail: `${esc(fish.location)} · ${detailBy}`,
      };
    };
    if (chosenFish) return buildFish(chosenFish);
    const bestDrop = dropPlans[0] || null;
    const bestFish = fishPlans.length ? buildFish(fishPlans[0]) : null;
    // When an item can be both explored and fished, the cheaper one leads
    // unless a route rule prefers exploring. Exploring used to win outright,
    // which went unnoticed until Sinking Swamp gave Water Lily an exploring
    // route beside the Forest Pond nets it is actually farmed with.
    if (bestDrop && bestFish && !bestDrop.preferred && bestFish.goldEq != null
      && (bestDrop.goldEq == null || bestFish.goldEq < bestDrop.goldEq)) return bestFish;
    return bestDrop || bestFish;
  }

  function farmLocationChoices(item, need, m, consts) {
    const sources = E.sourcesFor(index, item.id, Math.max(1, need), m, consts);
    const rows = [];
    for (const row of sources.drops || []) {
      if (row.explores != null && (state.includeEvents || !EVENT_LOCATIONS.has(row.location))) {
        rows.push({ location: row.location, kind: "Explore", event: EVENT_LOCATIONS.has(row.location) });
      }
    }
    for (const row of sources.fish || []) {
      if (row.catches != null && (state.includeEvents || !EVENT_LOCATIONS.has(row.location))) {
        rows.push({ location: row.location, kind: "Fish", event: EVENT_LOCATIONS.has(row.location) });
      }
    }
    // Sinking Swamp is an exploring place and a fishing place under one name,
    // so the same name can appear once per kind.
    return rows.filter((row, i) => rows.findIndex((other) => other.location === row.location && other.kind === row.kind) === i);
  }

  function locationSelect(item, need, m, route) {
    if (!route || !["explore", "fish"].includes(route.type)) return "";
    // Only the places for the way you chose to gather; Explore and Fish are
    // picked in "Get it by" now.
    const choices = farmLocationChoices(item, need, m, constants()).filter((choice) => choice.kind === (route.type === "fish" ? "Fish" : "Explore"));
    if (!choices.length) return "";
    const selected = state.farmLocations[item.id] || route.location || "";
    return `<label class="location-choice"><span>Farm at</span><select data-location-id="${item.id}">${choices.map((choice) => `<option value="${esc(choice.location)}" ${selected === choice.location ? "selected" : ""}>${choice.event ? "Event · " : ""}${esc(choice.location)} · ${choice.kind}</option>`).join("")}</select></label>`;
  }

  function makeMaterialQuote(node, m, consts) {
    const subtree = E.resolveTree(index, node.id, node.qtyOut, m, 0, [], consts);
    const leaves = E.flattenLeaves(subtree);
    let totalGold = 0;
    let priced = 0;
    let count = 0;
    const routes = [];
    for (const [, leaf] of leaves) {
      if (leaf.id == null) continue;
      count += 1;
      const item = index.itemsById.get(leaf.id);
      const infra = infraFor(item, leaf.total, m);
      if (infra) {
        priced += 1;
        routes.push({ name: item.name, type: "covered", goldEq: 0 });
        continue;
      }
      const quote = E.marketQuote(index, leaf.id, leaf.total);
      const farm = farmPlan(item, leaf.total, m, consts);
      const choices = [
        quote && quote.best.goldEq != null && { type: "trade", goldEq: quote.best.goldEq },
        farm && farm.goldEq != null && { type: "farm", goldEq: farm.goldEq },
      ].filter(Boolean).sort((a, b) => a.goldEq - b.goldEq);
      if (choices.length) {
        totalGold += choices[0].goldEq;
        priced += 1;
        routes.push({ name: item.name, ...choices[0] });
      }
    }
    return { goldEq: totalGold, complete: count > 0 && priced === count, priced, count, routes };
  }

  // Mastery counts every item a craft gives you, duplicates included. So the
  // number that matters is crafts, not items: 1,000,000 Yarn at 1.45x per
  // craft is 689,656 crafts. Mushroom Stew never applies to crafting.
  // The mastery line under the goal, for any item that has a mastery -
  // crafted or gathered - and nothing for one that has none (Emberstone).
  // Which items have one: the Most Masteries workbook (P.items[].mastery) and
  // the player's own Mastery page. Mushroom Stew makes each item count 1.1x.
  function masteryHtml(goal, m, crafted) {
    const key = goal.name.toLowerCase();
    const row = ((state.account && state.account.masteries) || []).find((entry) => String(entry.itemName || "").toLowerCase() === key);
    const known = !!((P.items[goal.name] || {}).mastery) || !!row;
    const per = crafted ? (m.craftYield || 1) : 1;
    const lines = [];
    if (crafted) lines.push(per > 1 ? `<b>${fmt(Math.ceil(state.qty / per))} crafts</b> (${fmt(per)}× per craft).` : `<b>${fmt(state.qty)} crafts</b>.`);
    if (!known) return lines.length ? `<p class="goal-crafts">${lines.join(" ")}</p>` : "";
    const stew = !!state.meals.mushroom;
    const boost = stew ? 1 + c("mushroom_mastery_bonus", 0.1) : 1;
    const unit = crafted ? "crafts" : "items";
    const count = (mastery) => Math.ceil(Math.ceil(mastery / boost) / per);
    let button = "";
    let have = null;
    try { have = towerMasteryMap().get(key); } catch (_) { have = null; }
    if (have != null) {
      // The Mastery page says the next target itself (Amber Cane: 1k, a fossil:
      // 10); without it the planner assumes the usual 100k / 1m.
      const pageTarget = Number(row && row.progressTarget) || 0;
      const target = pageTarget > have ? pageTarget : have < GM_GOAL ? GM_GOAL : have < MM_GOAL ? MM_GOAL : 0;
      if (target) {
        const left = target - have;
        const name = target === MM_GOAL ? "MM" : target === GM_GOAL ? "GM" : "The next tier";
        lines.push(`${name} needs ${fmt(left)} more mastery — <b>${fmt(count(left))} ${unit}</b>${stew ? " with Mushroom Stew" : ""}.`);
        const items = Math.ceil(left / boost);
        if (items !== state.qty) button = `<button type="button" class="text-action" data-plan-mastery="${items}">Plan just the ${fmt(items)}</button>`;
      } else {
        lines.push("Already Mega Mastered.");
      }
    } else {
      lines.push(`Has a mastery: Mega Mastery at 1m — <b>${fmt(count(MM_GOAL))} ${unit}</b>${stew ? " with Mushroom Stew" : ""}.`);
    }
    const chip = `<label class="path-mini${stew ? " on" : ""}" title="+10% mastery for 5 minutes"><input type="checkbox" data-gather-meal="mushroom" ${stew ? "checked" : ""}> Mushroom Stew</label>`;
    return `<p class="goal-crafts">${lines.join(" ")} ${button}</p><div class="path-choices compact goal-meal">${chip}</div>`;
  }

  function makeDecision(node, m, consts) {
    const item = index.itemsById.get(node.id);
    // The planner does not pick a route. Until the player chooses, a craftable
    // item is made from its recipe - that is just the recipe, not a judgement
    // that crafting is best. Old saved "auto" choices read the same way.
    const stored = state.makeChoices[node.id];
    const infra = infraFor(item, node.qtyOut, m);
    // The one thing filled in without asking: what your own farm buildings
    // already make (Steel, Steel Wire, Board, Straw...), as set on Setup.
    const manual = stored && stored !== "auto" ? stored : (infra ? "building" : "craft");
    const direct = E.marketQuote(index, node.id, node.qtyOut);
    const farm = farmPlan(item, node.qtyOut, m, consts);
    const materials = makeMaterialQuote(node, m, consts);
    const auto = "craft";
    const reason = "";
    const cashWinner = { action: "craft" };
    const progressionWinner = "craft";
    const action = manual;
    return {
      action,
      auto,
      reason,
      direct,
      farm,
      materials,
      infra,
      manual,
      cashWinner: cashWinner.action,
      progressionWinner,
    };
  }

  function sourceRoute(item, missing, m, consts) {
    if (missing <= 0) return { type: "owned", label: "Inventory", detail: "Already covered", goldEq: 0 };
    if (state.sourceChoices[item.id] === "free") return { type: "covered", label: "You have it", detail: "Not costed — you said you have it or get it free", goldEq: 0 };
    const decision = state.decisionActions.get(item.id);
    const infra = infraFor(item, missing, m);
    if (decision === "building" || infra && !decision) {
      return { type: "covered", label: infra.kind, detail: infra.detail, hours: infra.hours, goldEq: 0 };
    }
    if (decision === "trade") {
      const direct = E.marketQuote(index, item.id, missing);
      return direct ? { type: "trade", label: "Buy in trade", detail: quoteText(direct), quote: direct, goldEq: direct.best.goldEq } : { type: "unknown", label: "No quote", detail: "Trade was selected but no saved price exists" };
    }
    if (decision === "farm") {
      const chosenFarm = farmPlan(item, missing, m, consts);
      return chosenFarm
        ? Object.assign({ label: farmLabel(chosenFarm) }, chosenFarm)
        : { type: "unknown", label: "No farm route", detail: "Farm was selected but no measured route exists" };
    }

    const source = E.sourcesFor(index, item.id, missing, m, consts);
    const trade = E.marketQuote(index, item.id, missing);
    const farm = farmPlan(item, missing, m, consts);
    const vendor = source.vendor ? { type: "vendor", label: "Country Store", silver: source.vendor.priceEach * missing, detail: `${fmt(source.vendor.priceEach * missing)} silver` } : null;
    const choice = state.sourceChoices[item.id] || "auto";
    if (choice === "covered" && infra) return { type: "covered", label: infra.kind, detail: infra.detail, hours: infra.hours, goldEq: 0 };
    if (choice === "trade" && trade && !isFish(item)) return { type: "trade", label: "Buy in trade", detail: quoteText(trade), quote: trade, goldEq: trade.best.goldEq };
    if (choice === "farm" && farm) return Object.assign({ label: farm.type === "fish" ? "Fish" : farm.type === "crop" ? "Grow" : farm.type === "acorn" ? "Acorn test" : "Explore" }, farm);
    if (choice === "explore" || choice === "fish") {
      const kept = farmPlan(item, missing, m, consts, choice);
      if (kept) return Object.assign({ label: choice === "fish" ? "Fish" : "Explore" }, kept);
    }
    if (choice === "grow" && source.crop) return Object.assign({ label: "Grow" }, cropPlan(item, missing, source));
    if (choice === "vendor" && vendor) return vendor;
    if (choice !== "auto") return { type: "unknown", label: "Unavailable", detail: "That route is not known for this item" };

    // Nothing chosen yet. The planner used to pick the cheapest route here; it
    // no longer decides for the player, so it asks - except for what the
    // player's own buildings already make, which is a fact of their farm.
    if (infra) return { type: "covered", label: infra.kind, detail: infra.detail, hours: infra.hours, goldEq: 0 };
    if (farm || trade || vendor) {
      return { type: "choose", label: "Choose", detail: "Pick how you will get this from the list", goldEq: null };
    }
    // Everything else: every way the game hands it out, from buddy.farm
    // (data/item-sources.js) - pets, mining, chests, the Temple, quests...
    // Logged in an ordinary place during an event (painted eggs, snowballs) -
    // data/event-drops.js took it out of the tables, so say why it is missing.
    const eventAt = (window.FRPG_EVENT_DROPS || {})[item.name];
    if (eventAt) return { type: "unknown", label: "Event only", detail: `<span class="where-from"><span>Only during an event - it was logged at ${esc(eventAt.map((at) => at.place).join(", "))} while one was on. Not a normal drop.</span></span>` };
    const where = (window.FRPG_ITEM_SOURCES && window.FRPG_ITEM_SOURCES.items || {})[item.name];
    if (where) return { type: "unknown", label: where.repeat ? "Where to get it" : "Not farmable", detail: `<span class="where-from">${where.lines.map((line) => `<span>${esc(line)}</span>`).join("")}</span>` };
    if (isFish(item)) return { type: "unknown", label: "Fish for it", detail: "No fishing rate recorded for this one yet" };
    const mine = mineFor(item.name);
    if (mine) return { type: "unknown", label: "Mine it", detail: `Found in ${esc(mine.name)}${mine.pickaxe ? ` with the ${esc(mine.pickaxe)}` : ""}. Mining rates are not recorded yet — see the Mining tab.` };
    return { type: "unknown", label: "Not known yet", detail: "No reliable way to get this one is recorded yet" };
  }

  function routeOptions(item, route, m) {
    const source = E.sourcesFor(index, item.id, 1, m, constants());
    const options = [["auto", "Choose…"]];
    // Craft was missing here entirely: an item with a recipe -- Twine, Rope,
    // any of the dyes -- could be listed as something to go and get with no way
    // to say "I will make it". It sets the make choice rather than the route,
    // because crafting is what expands the item into its own inputs.
    const craftable = (index.craftByItem.get(item.id) || []).length > 0;
    if (craftable) options.push(["craft", "Craft"]);
    const gather = farmPlan(item, 1, m, constants());
    // Both ways open (Water Lily): offer Explore and Fish side by side rather
    // than one "Explore" with the fishing spots hidden in the place list.
    const canExplore = !!farmPlan(item, 1, m, constants(), "explore");
    const canFish = !!farmPlan(item, 1, m, constants(), "fish");
    const bothWays = canExplore && canFish;
    if (bothWays) options.push(["explore", "Explore"], ["fish", "Fish"]);
    else if (gather) options.push(["farm", farmLabel(gather)]);
    if (source.crop && gather && gather.type !== "crop") options.push(["grow", "Grow"]);
    if (!isFish(item) && E.marketQuote(index, item.id, 1)) options.push(["trade", "Trade"]);
    if (!isFish(item) && source.vendor) options.push(["vendor", "Store"]);
    if (infraFor(item, 1, m)) options.push(["covered", "Covered"]);
    // Any item can be one you already have, get free or just don't want
    // costed — a gift, a reward, a stack in storage. It then costs nothing and
    // stops the tree there.
    options.push(["free", "I have it / free"]);
    const stored = state.sourceChoices[item.id] || "auto";
    const selected = state.makeChoices[item.id] === "craft" && craftable
      ? "craft"
      : bothWays && stored === "farm" ? (gather && gather.type === "fish" ? "fish" : "explore")
      : stored;
    return `<select class="route-select" data-source-id="${item.id}" aria-label="Acquisition route for ${esc(item.name)}">${options.map(([value, label]) => `<option value="${value}" ${selected === value ? "selected" : ""}>${label}</option>`).join("")}</select>`;
  }

  // The game will not let you mail some items, so there is no trade route for
  // them at any price. Absence from the list means unknown, not tradeable.
  const CANNOT_MAIL = new Set(((window.FRPG_TRADEABLE || {}).cannotMail || []).map((n) => String(n).toLowerCase()));
  const canTrade = (item) => !!item && !CANNOT_MAIL.has(String(item.name || "").toLowerCase());

  // Meals that genuinely move the numbers for this kind of run, toggleable
  // wherever the run is shown. The Hide control collapses the row only — it
  // never changes whether a meal is on.
  function mealStripFor(kind) {
    const meals = [
      kind === "fish" && { id: "seapincher", label: "Sea Pincher Special", note: "nets catch 10% more" },
      kind !== "fish" && { id: "quandary", label: "Quandary Chowder", note: "10% more per Arnold Palmer" },
      kind !== "fish" && { id: "neigh", label: "Neigh", note: "Cider uses 20% less stamina" },
      { id: "mushroom", label: "Mushroom Stew", note: "each item counts 1.1x toward a mastery" },
    ].filter(Boolean);
    const activeCount = meals.filter((meal) => state.meals[meal.id]).length;
    const hidden = !!state.mealStripHidden;
    return `<div class="gather-path meal-strip">` +
      `<span class="meal-strip-head">Meals in these numbers<small>${activeCount} on</small>` +
      `<button type="button" class="meal-strip-toggle" data-meal-strip aria-expanded="${!hidden}">${hidden ? "Show" : "Hide"}</button></span>` +
      `<div class="meal-chips"${hidden ? " hidden" : ""}>` +
      meals.map((meal) => `<label class="meal-chip${state.meals[meal.id] ? " on" : ""}" title="${esc(meal.label)} — ${esc(meal.note)}">` +
        `<input type="checkbox" data-gather-meal="${meal.id}" ${state.meals[meal.id] ? "checked" : ""}>` +
        `${itemImg(itemByName(meal.label), "meal-chip-art", meal.label)}` +
        `<span class="meal-chip-name">${esc(meal.label)}</span></label>`).join("") +
      `</div></div>`;
  }

  // What you actually pay, at your own rate. Trade prices move constantly and
  // every player buys at a different number, so the quote is only a starting
  // suggestion — type over it and the plan uses your figure.
  const BUY_CURRENCIES = [["ap", "Arnold Palmer"], ["ac", "Apple Cider"], ["oj", "Orange Juice"], ["gold", "Gold"]];
  function buyRate(item) {
    const saved = state.buyRates[item.id];
    if (saved && saved.perK > 0) return saved;
    const quote = E.marketQuote(index, item.id, 1000);
    if (quote && quote.best) {
      const cur = quote.best.currency === "gold" ? "gold" : quote.best.currency;
      return { perK: quote.best.rate, currency: BUY_CURRENCIES.some(([k]) => k === cur) ? cur : "ap", suggested: true };
    }
    return null;
  }
  function buyRateBlock(item, missing) {
    if (!canTrade(item)) {
      return `<div class="path-buy muted"><b>Or buy it</b> <small>${esc(item.name)} cannot be mailed, so there is no trade route for it.</small></div>`;
    }
    const rate = buyRate(item);
    const perK = rate ? rate.perK : "";
    const cur = rate ? rate.currency : "ap";
    const units = rate && rate.perK > 0 ? (Math.max(1, missing) / 1000) * rate.perK : null;
    const curName = (BUY_CURRENCIES.find(([k]) => k === cur) || [, "Arnold Palmer"])[1];
    return `<div class="path-buy">
      <b>Or buy it</b>
      <span class="buy-rate">
        <input class="buy-per-k" type="number" min="0" step="0.1" inputmode="decimal"
               value="${perK === "" ? "" : esc(String(round2(perK)))}" placeholder="rate"
               data-buy-id="${item.id}" aria-label="What you pay per 1,000 ${esc(item.name)}">
        <select class="buy-cur" data-buy-cur="${item.id}" aria-label="What you pay in">
          ${BUY_CURRENCIES.map(([k, label]) => `<option value="${k}" ${cur === k ? "selected" : ""}>${label}</option>`).join("")}
        </select>
        <small>per 1,000</small>
      </span>
      ${units != null ? `<small class="buy-total">${fmt(missing)} costs about <b>${fmt(units)} ${esc(curName)}</b>${rate.suggested ? " — quoted rate, change it to yours" : ""}</small>` : `<small class="buy-total muted">Enter what you pay and I'll total it.</small>`}
    </div>`;
  }

  // Every way to get this one ingredient, side by side with real numbers, so
  // the choice is the player's and nothing is hidden behind a verdict.
  function pathChoices(item, route, missing, m) {
    if (!route) return "";
    // On a bought row the only thing worth showing is what you pay for it.
    if (["trade", "vendor"].includes(route.type)) return `<div class="path-choices">${buyRateBlock(item, missing)}</div>`;
    const meal = (id, label, note) => `<label class="path-mini${state.meals[id] ? " on" : ""}" title="${esc(note)}"><input type="checkbox" data-gather-meal="${id}" ${state.meals[id] ? "checked" : ""}> ${label}</label>`;
    if (route.type === "fish") {
      const method = FISH_METHODS[state.fishMethods[item.id]] ? state.fishMethods[item.id] : "large";
      const how = (value, label) => `<label class="path-mini${method === value ? " on" : ""}"><input type="radio" name="fish-${item.id}" value="${value}" ${method === value ? "checked" : ""} data-fish-method="${item.id}"> ${label}</label>`;
      return `<div class="path-choices compact">${how("large", "Large Nets")}${how("net", "Fishing Nets")}${how("hand", "By hand")}<span class="path-sep">Meal</span>${meal("seapincher", "Sea Pincher Special", "Nets catch about 10% more")}</div>`;
    }
    if (!["explore", "acorn"].includes(route.type)) return "";
    const chosen = state.drinkChoices[item.id] === "ap" ? "ap" : "cider";
    const perks = [
      state.enabled.has("wanderer") && "Wanderer",
      state.meals.neigh && "Neigh",
    ].filter(Boolean);
    const staminaNote = perks.length ? `${perks.join(" + ")} applied` : "no stamina perks on";
    const apNote = state.meals.quandary ? "Quandary Chowder applied" : "without Quandary Chowder";

    const cider = route.ciders != null ? `
      <label class="path-pick${chosen === "cider" ? " on" : ""}">
        <input type="radio" name="drink-${item.id}" value="cider" ${chosen === "cider" ? "checked" : ""} data-drink-id="${item.id}">
        <span><b>Explore with Apple Cider</b>
          <small>${fmt(route.ciders)} Cider · ${fmt(route.stamina)} stamina — ${esc(staminaNote)}</small></span>
      </label>` : "";

    const ap = route.aps != null ? `
      <label class="path-pick${chosen === "ap" ? " on" : ""}">
        <input type="radio" name="drink-${item.id}" value="ap" ${chosen === "ap" ? "checked" : ""} data-drink-id="${item.id}">
        <span><b>Use Arnold Palmers</b>
          <small>${fmt(route.aps)} Arnold Palmer — ${esc(apNote)}</small></span>
      </label>` : `
      <div class="path-pick muted"><span><b>Use Arnold Palmers</b>
        <small>no measured per-AP rate for this one</small></span></div>`;

    const buy = buyRateBlock(item, missing);

    const pick = (value, label, off) => `<label class="path-mini${chosen === value ? " on" : ""}${off ? " muted" : ""}"><input type="radio" name="drink-${item.id}" value="${value}" ${chosen === value ? "checked" : ""} ${off ? "disabled" : ""} data-drink-id="${item.id}"> ${label}</label>`;
    return `<div class="path-choices compact">${pick("cider", "Cider", route.ciders == null)}${pick("ap", "Arnold Palmer", route.aps == null)}<span class="path-sep">Meals</span>${chosen === "ap" ? meal("quandary", "Quandary Chowder", "10% more from each Arnold Palmer") : meal("neigh", "Neigh", "Cider uses 20% less stamina")}</div>`;
  }

  // "1m", "250k", "1.5m" or "1,000,000" — the quick buttons were replaced by
  // letting the box read shorthand.
  function parseQty(value) {
    const text = String(value || "").toLowerCase().replace(/[,\s_]/g, "");
    const short = text.match(/^(\d*\.?\d+)([km])$/);
    if (short) return Math.round(parseFloat(short[1]) * (short[2] === "m" ? 1e6 : 1e3));
    return parseInt(text.replace(/\D/g, ""), 10) || 0;
  }

  // What one ingredient costs, in one line, in what the player chose to spend.
  function costLine(item, route) {
    if (!route) return "";
    if (route.type === "choose") {
      const eventAt = (window.FRPG_EVENT_DROPS || {})[item.name];
      return eventAt ? `<span class="where-from"><span>Event only - not a normal drop at ${esc(eventAt.map((at) => at.place).join(", "))}. You can still trade for it.</span></span>` : "";
    }
    if (route.type === "explore" || route.type === "acorn") {
      const ap = state.drinkChoices[item.id] === "ap" && route.aps != null;
      if (ap) return `${fmt(route.aps)} Arnold Palmer at ${esc(route.location)}`;
      const eff = locationEffectiveness(route.location);
      return `${fmt(route.ciders)} Cider · ${fmt(route.stamina)} stamina at ${esc(route.location)}` +
        `<label class="eff-inline" title="Your exploring effectiveness at ${esc(route.location)}, shared with Places and Trips">Effectiveness <input type="number" min="0" step="1" inputmode="numeric" data-eff-place="${esc(route.location)}" value="${eff || ""}" placeholder="0"></label>`;
    }
    return route.detail || "";
  }

  function routeEvidence(item, route) {
    const lines = [];
    if (route.coDrops && route.coDrops.length) lines.push(`<span class="drop-chips">${route.coDrops.map((drop) => {
      const dropItem = itemByName(drop.name);
      const exactRate = ((EXACT_AP_RATES[route.location] || {})[drop.name]) || null;
      const rate = exactRate ? `${Number(exactRate.value).toFixed(2)} ${exactRate.unit}` : "";
      return `<span class="drop-chip">${itemImg(dropItem, "drop-art", drop.name)}<span><b>${fmt(drop.expected)}</b><small>${esc(drop.name)}</small>${rate ? `<small>${rate}</small>` : ""}</span></span>`;
    }).join("")}</span>`);
    const questNeeds = questNeedsHtml(item.name);
    if (questNeeds) lines.push(questNeeds);
    // Other ways the game hands it out (pets, chests, the Temple...), when the
    // row is costed one way. An item with no route already lists them in place.
    const other = route.type === "unknown" ? null : ((window.FRPG_ITEM_SOURCES || {}).also || {})[item.name];
    if (other) lines.push(`<span class="where-from"><b>Other ways to get it</b>${other.map((line) => `<span>${esc(line)}</span>`).join("")}</span>`);
    const drops = route.coDrops && route.coDrops.length;
    const parts = [drops ? `${route.type === "fish" ? "Also catches" : "Also drops"} (${drops})` : "", questNeeds ? "quests" : "", other ? "other ways" : ""].filter(Boolean);
    const summary = parts.length ? parts.join(" · ").replace(/^./, (c) => c.toUpperCase()) : "";
    return lines.length ? `<details class="route-evidence"><summary>${summary}</summary><small class="route-evidence-body">${lines.join("")}</small></details>` : "";
  }
  // Everything hanging off a craft used to render bare, which made fished and
  // explored items look like things you craft. Say how each one is actually got.
  const treeRouteWord = (route) => {
    if (!route) return "";
    switch (route.type) {
      case "fish": return "fish for it";
      case "crop": return "grow it";
      case "explore": return "explore for it";
      case "acorn": return "explore with Acorn Pie";
      case "trade": return "buy in trade";
      case "vendor": return "buy at the Country Store";
      case "covered": return "your farm covers it";
      case "owned": return "already in your inventory";
      default: return "";
    }
  };
  function treeHtml(node) {
    const item = index.itemsById.get(node.id);
    if (node.cyclic) return `<div class="leaf cyclic">↻ ${esc(node.name)} — circular recipe</div>`;
    if (!node.children.length) {
      const how = treeRouteWord(leafRoutes.get(node.id)) || (node.stopped ? "get ready-made" : "");
      return `<div class="leaf">${itemImg(item, "tree-art", node.name)}<span class="node-amt">×${fmt(node.qtyOut)}</span>${esc(node.name)}${how ? `<span class="node-kind">${esc(how)}</span>` : ""}</div>`;
    }
    return `<details ${state.treeOpen ? "open" : ""}><summary>${itemImg(item, "tree-art", node.name)}<span class="node-amt">×${fmt(node.qtyOut)}</span>${esc(node.name)}<span class="node-kind">${node.kind} ×${fmt(node.craftsNeeded)}</span></summary>${node.children.map(treeHtml).join("")}</details>`;
  }
  // ---- Gathered goals (fish / explore / grow) -------------------------------
  // Farm RPG does not craft a Drum. When the goal has no recipe, the craft
  // scaffolding is hidden and this panel answers the real question instead.
  const FISH_METHODS = {
    hand:  { label: "By hand",      note: "one cast at a time" },
    net:   { label: "Fishing Nets", note: "" },
    large: { label: "Large Nets",   note: "" },
  };

  const GATHER_WORDS = {
    fish:  { verb: "you fish for this one",     noun: "Fishing",   place: "Best pond",   act: "casts",    actTitle: "Casts",    also: "Also caught here" },
    explore:{ verb: "you explore for this one", noun: "Exploring", place: "Best place",  act: "explores", actTitle: "Explores", also: "Also found here" },
    acorn: { verb: "you explore for this one",  noun: "Exploring", place: "Best place",  act: "explores", actTitle: "Explores", also: "Also found here" },
    crop:  { verb: "you grow this one",         noun: "Growing",   place: "On the farm", act: "plants",   actTitle: "Plants",   also: "" },
  };

  function gatherRankedPlaces(goal, need, m) {
    const src = E.sourcesFor(index, goal.id, Math.max(1, need), m, constants());
    const rows = [];
    for (const row of src.fish || []) {
      if (row.catches != null && (state.includeEvents || !EVENT_LOCATIONS.has(row.location)))
        rows.push({ location: row.location, kind: "fish", denom: row.denom, actions: row.catches });
    }
    for (const row of src.drops || []) {
      if (row.explores != null && (state.includeEvents || !EVENT_LOCATIONS.has(row.location)))
        rows.push({ location: row.location, kind: "explore", denom: row.denom, actions: row.explores });
    }
    return rows.sort((a, b) => a.actions - b.actions);
  }

  function renderGatherPanel(goal, m, goalIsCrafted, tradeGoldEq) {
    const panel = $("gatherPanel");
    if (!panel) return;
    const need = Math.max(1, state.qty);
    const plan = goalIsCrafted ? null : farmPlan(goal, need, m, constants());
    const gathered = !!plan && !!GATHER_WORDS[plan.type];

    // Craft-shaped furniture only makes sense for something you craft.
    for (const [id, hide] of [["treeCard", gathered]]) {
      const node = $(id);
      if (node) node.classList.toggle("hidden", hide);
    }
    if ($("workbenchTitle")) $("workbenchTitle").textContent = gathered ? "How you get it" : "Items you still need";

    // The long "explore for it" breakdown repeated what the row below shows
    // once a route is picked, so a gathered goal is just that row now.
    panel.classList.add("hidden");
    panel.innerHTML = "";
  }

  const round2 = (n) => Math.round(Number(n) * 100) / 100;

  const metric = (key, value, note) => `<div class="route-metric"><span>${key}${note ? `<small>${note}</small>` : ""}</span><b>${value}</b></div>`;
  const trail = (label, value, note, tone) => `<div class="trail-stop ${tone || ""}"><span>${label}</span><strong>${value}</strong><small>${note || ""}</small></div>`;

  // The Calculate page before an item is chosen. A bare "pick something" was
  // the least useful screen on the site, so it offers the player's own next
  // unfinished Tower masteries: the thing they most often come here to cost.
  function renderEmptySuggestions() {
    const box = $("emptySuggest");
    if (!box) return;
    let needs = [];
    try { needs = towerRequirements(); } catch (_) { needs = []; }
    const picks = needs.filter((row) => !row.complete && itemByName(row.name)).slice(0, 6);
    box.hidden = !picks.length;
    box.innerHTML = picks.map((row) =>
      `<button type="button" class="empty-pick" data-empty-pick="${esc(row.name)}" data-empty-qty="${row.remaining}">` +
      `${itemImg(itemByName(row.name), "empty-art", row.name)}` +
      `<span><b>${esc(row.name)}</b><small>T${row.floor} · ${fmt(row.remaining)} left</small></span></button>`).join("");
    box.querySelectorAll("[data-empty-pick]").forEach((button) => {
      button.onclick = () => window.FRPG_openItem(button.dataset.emptyPick, Number(button.dataset.emptyQty));
    });
  }

  function render() {
    el.error.classList.add("hidden");
    if (!state.itemId || !state.qty) {
      el.result.classList.add("hidden"); el.empty.classList.remove("hidden"); renderEmptySuggestions(); return;
    }
    const consts = constants(), m = mods();
    let fullTree;
    try {
      fullTree = E.resolveTree(index, state.itemId, state.qty, m, 0, [], consts);
    } catch (error) {
      el.error.textContent = error.message; el.error.classList.remove("hidden"); return;
    }

    // How much of an ingredient you need depends on which of its parents are
    // still being crafted, and that depends on the decisions themselves. So
    // settle the two together: size every decision against the current tree,
    // re-resolve the tree with the resulting "buy/farm instead" stops, and
    // repeat until the stops stop changing. Sizing them once against the
    // fully-expanded tree overstated shared ingredients — Glass Orb read 12m
    // when the plan it was shown next to only needed 8m, because Red Dye was
    // being bought rather than crafted through Glass Bottle.
    const fullNodes = E.collectNodes(fullTree);
    const craftableIds = [...fullNodes.values()].filter((node) => node.children && node.children.length).map((node) => node.id);
    let tree = fullTree;
    let treeNodes = fullNodes;
    let decisions = [];
    let stopIds = new Set();
    for (let pass = 0; pass < 4; pass += 1) {
      const passDecisions = [];
      const passStops = new Set();
      const passActions = new Map();
      for (const id of craftableIds) {
        const sized = treeNodes.get(id);
        if (!sized) continue; // pruned away by a stop higher up the tree
        const item = index.itemsById.get(id);
        if (!item) continue;
        const node = { id, name: item.name, qtyOut: sized.qtyOut };
        const direct = E.marketQuote(index, id, node.qtyOut);
        const infra = infraFor(item, node.qtyOut, m);
        const farm = farmPlan(item, node.qtyOut, m, consts);
        const free = state.sourceChoices[id] === "free";
        if (!direct && !infra && !farm && !free) continue;
        const decision = free
          ? { action: "building", auto: "building", reason: "You have it or get it free", direct, farm, materials: { goldEq: 0, complete: true }, infra: null, manual: "free", cashWinner: "inventory", progressionWinner: "inventory" }
          : makeDecision(node, m, consts);
        passDecisions.push({ node, item, ...decision });
        passActions.set(id, decision.action);
        if (["trade", "building", "farm"].includes(decision.action)) passStops.add(id);
      }
      const settled = pass > 0 && passStops.size === stopIds.size && [...passStops].every((id) => stopIds.has(id));
      decisions = passDecisions;
      stopIds = passStops;
      state.decisionActions = passActions;
      tree = E.resolveTree(index, state.itemId, state.qty, m, 0, [], consts, stopIds);
      treeNodes = E.collectNodes(tree);
      if (settled) break;
    }
    const activeNodeIds = new Set(treeNodes.keys());
    const activeDecisions = decisions.filter((decision) => activeNodeIds.has(decision.node.id));
    const leaves = E.flattenLeaves(tree);
    const rows = [...leaves.values()].filter((leaf) => leaf.id != null).map((leaf) => {
      const item = index.itemsById.get(leaf.id);
      const owned = Number(state.owned[leaf.id] || 0);
      const missing = Math.max(0, leaf.total - owned);
      return { leaf, item, owned, missing, route: sourceRoute(item, missing, m, consts) };
    }).sort((a, b) => b.missing - a.missing);
    leafRoutes = new Map(rows.map((row) => [row.item.id, row.route]));

    let craftSilver = E.treeCraftSilver(tree, m);
    let vendorSilver = 0, tradeGoldEq = 0, farmGoldEq = 0, rawSellValue = 0;
    let explores = 0, stamina = 0, ciders = 0, aps = 0, oj = 0, largeNets = 0, plants = 0, passiveHours = 0;
    let acornPies = 0, acornActions = 0, acornUses = 0, acornBulk = 1, acornBulkMeal = null;
    let independentExplores = 0;
    const tradeCurrency = { gold: 0, ap: 0, oj: 0 };
    const exploreBundles = new Map();
    for (const row of rows) {
      const route = row.route;
      if (row.item.sell != null) rawSellValue += row.missing * row.item.sell * m.saleMult;
      if (route.type === "vendor") vendorSilver += route.silver || 0;
      if (route.type === "trade" && route.quote) {
        const best = route.quote.best;
        tradeCurrency[best.currency] += best.amount;
        tradeGoldEq += best.goldEq || 0;
      }
      if (route.type === "explore") {
        independentExplores += route.explores || 0;
        const previous = exploreBundles.get(route.location);
        if (!previous || (route.explores || 0) > (previous.explores || 0)) exploreBundles.set(route.location, route);
      } else {
        if (["fish", "acorn"].includes(route.type)) farmGoldEq += route.goldEq || 0;
        if (route.type === "acorn") {
          acornPies += route.pies || 0;
          acornActions += route.actions || 0;
          acornUses += route.uses || 0;
          if ((route.bulk || 1) > acornBulk) { acornBulk = route.bulk; acornBulkMeal = route.bulkMeal; }
        }
        stamina += route.stamina || 0;
        ciders += route.method === "cider" ? route.ciders || route.uses || 0 : 0;
        aps += route.method === "ap" ? route.aps || route.uses || 0 : 0;
        oj += route.oj || 0;
      }
      largeNets += route.largeNets || 0;
      plants += route.plants || 0;
      passiveHours = Math.max(passiveHours, route.hours || 0);
    }
    for (const route of exploreBundles.values()) {
      farmGoldEq += route.goldEq || 0;
      explores += route.explores || 0;
      stamina += route.method === "cider" ? route.stamina || 0 : 0;
      ciders += route.method === "cider" ? route.ciders || 0 : 0;
      aps += route.method === "ap" ? route.aps || 0 : 0;
      oj += route.method === "cider" ? route.oj || 0 : 0;
    }
    const sharedExploreSavings = Math.max(0, independentExplores - explores);
    const goal = index.itemsById.get(state.itemId);
    const outputSell = goal.sell != null ? goal.sell * m.saleMult * state.qty : null;
    const netSilver = outputSell == null ? null : outputSell - craftSilver - vendorSilver;
    const trueNet = netSilver == null ? null : netSilver - rawSellValue;
    const coveredRows = rows.filter((row) => row.route.type === "covered");
    const visibleRows = state.showCovered ? rows : rows.filter((row) => row.route.type !== "covered");
    const chosenCounts = rows.reduce((acc, row) => { acc[row.route.type] = (acc[row.route.type] || 0) + 1; return acc; }, {});
    const cashBuyCount = activeDecisions.filter((decision) => decision.cashWinner === "trade").length;
    const progressionFarmCount = activeDecisions.filter((decision) => decision.progressionWinner === "farm").length;

    el.empty.classList.add("hidden"); el.result.classList.remove("hidden");
    // A fished or explored goal has no recipe, so crafting language (and the
    // crafting-yield chip) doesn't apply to it.
    const goalIsCrafted = !!(fullTree.children && fullTree.children.length);
    const goalSummary = goalIsCrafted
      ? `${plural(rows.length, "ingredient", "ingredients")} · ${coveredRows.length} from your farm${passiveHours ? ` (longest wait ${fmt(passiveHours)}h)` : ""}`
      : `Not a craft — you get this one directly. ${esc(capitalise(treeRouteWord(rows[0] && rows[0].route) || "see the route below"))}.`;
    $("goalHeader").innerHTML = `<div class="goal-identity">${itemImg(goal, "goal-art", goal.name)}<div class="goal-title"><h2>${esc(goal.name)} × ${fmt(state.qty)}</h2><p>${goalSummary}</p>${masteryHtml(goal, m, goalIsCrafted)}</div></div>`;
    $("goalHeader").querySelectorAll("[data-plan-mastery]").forEach((button) => {
      button.onclick = () => { state.qty = Number(button.dataset.planMastery); el.qty.value = state.qty.toLocaleString("en-US"); render(); };
    });
    // The four boxes that sat here (goal, buying, ingredients, farm) repeated
    // the line under the item name, so only the longest farm wait survives.
    $("resourceTrail").innerHTML = "";
    $("resourceTrail").hidden = true;
    // Every quest still asking for the item you opened, on the item itself.
    $("goalQuests").innerHTML = questNeedsHtml(goal.name);
    $("includeEvents").checked = state.includeEvents;
    if ($("drinkPath")) $("drinkPath").value = state.drinkPath;
    const staminaField = $("staminaMeasured");
    if (staminaField && document.activeElement !== staminaField) {
      const measured = Number(state.overrides.explore_stamina_measured || 0);
      staminaField.value = measured > 0 ? String(Math.round(measured * 100)) : "";
    }

    const bestText = Object.entries(chosenCounts).sort((a, b) => b[1] - a[1])[0];

    // A fished, explored or grown goal is not a production plan. Its recipe
    // tree, "mixed route" verdict and multi-ingredient shopping list are all
    // empty scaffolding, so stand them down and lead with what the player
    // actually asked: where do I get this, and what does it cost in nets or
    // drinks compared with just buying it.
    renderGatherPanel(goal, m, goalIsCrafted, tradeGoldEq);

    if (coveredRows.length) {
      el.covered.classList.remove("hidden");
      el.covered.innerHTML = `<p><b>Your farm covers:</b> ${coveredRows.map((row) => `${esc(row.item.name)} × ${fmt(row.missing)}`).join(" · ")}</p><label class="mini-check"><input type="checkbox" ${state.showCovered ? "checked" : ""} data-show-covered> Show in the list</label>`;
      el.covered.querySelector("[data-show-covered]").onchange = (event) => { state.showCovered = event.target.checked; $("toggleCovered").checked = state.showCovered; render(); };
    } else {
      el.covered.classList.add("hidden");
    }

    if (activeDecisions.length) {
      el.makeBuy.classList.remove("hidden");
      el.makeBuy.innerHTML = `<div class="section-heading compact"><div><h2>Make or get</h2></div></div><div class="decision-list">${activeDecisions.slice(0, 40).map((decision) => {
        const selected = state.sourceChoices[decision.item.id] === "free" ? "free" : decision.manual;
        const materialText = decision.materials.complete ? `${fmt(decision.materials.goldEq)} gold of ingredients` : `${decision.materials.priced} of ${decision.materials.count} ingredients priced so far`;
        const farmText = decision.farm ? `${farmLabel(decision.farm)} ${esc(decision.farm.location || "")}${decision.farm.goldEq != null ? ` · ${fmt(decision.farm.goldEq)} gold` : ""}` : "";
        const directText = decision.direct ? quoteText(decision.direct) : "";
        const infraText = decision.infra ? decision.infra.detail : "";
        const costText = selected === "farm" ? farmText : selected === "trade" ? directText : selected === "building" ? infraText : materialText;
        const codrops = decision.farm ? coDropSentence(decision.farm) : "";
        return `<div class="decision-row">${itemImg(decision.item, "small")}<div class="decision-copy"><strong>${esc(decision.item.name)} × ${fmt(decision.node.qtyOut)}</strong></div><div class="decision-controls"><select data-make-id="${decision.item.id}" aria-label="How to get ${esc(decision.item.name)}"><option value="craft" ${selected === "craft" ? "selected" : ""}>Craft it</option>${decision.farm ? `<option value="farm" ${selected === "farm" ? "selected" : ""}>Farm directly</option>` : ""}${decision.direct ? `<option value="trade" ${selected === "trade" ? "selected" : ""}>Buy/trade it</option>` : ""}${decision.infra ? `<option value="building" ${selected === "building" ? "selected" : ""}>Use ${esc(decision.infra.kind)}</option>` : ""}<option value="free" ${selected === "free" ? "selected" : ""}>I have it / free</option></select>${decision.farm && selected === "farm" ? locationSelect(decision.item, decision.node.qtyOut, m, decision.farm) : ""}</div></div>`;
      }).join("")}</div>`;
      el.makeBuy.querySelectorAll("[data-make-id]").forEach((select) => {
        select.onchange = () => {
          const id = select.dataset.makeId;
          if (select.value === "free") { state.sourceChoices[id] = "free"; delete state.makeChoices[id]; }
          else { if (state.sourceChoices[id] === "free") delete state.sourceChoices[id]; state.makeChoices[id] = select.value; }
          save(); render();
        };
      });
    } else {
      el.makeBuy.classList.add("hidden");
    }

    $("ingCount").textContent = `${visibleRows.length} shown · ${rows.length} active`;
    el.ingBody.innerHTML = visibleRows.map((row) => `<tr class="route-${row.route.type}"><td><div class="item-cell">${itemImg(row.item, "table-art")}<span><b>${esc(row.item.name)}</b>${row.leaf.stopped ? '<small>Getting this ready-made, so its own recipe is not broken down</small>' : ""}</span></div></td><td class="num">${fmt(row.leaf.total)}</td><td class="num"><input class="owned" data-id="${row.item.id}" inputmode="numeric" value="${row.owned || ""}" placeholder="0" aria-label="Owned quantity of ${esc(row.item.name)}"></td><td class="num">${fmt(row.missing)}</td><td>${routeOptions(row.item, row.route, m)}${locationSelect(row.item, row.missing, m, row.route)}</td><td><span class="route-detail">${costLine(row.item, row.route)}</span>${pathChoices(row.item, row.route, row.missing, m)}${routeEvidence(row.item, row.route)}</td></tr>`).join("");
    el.ingBody.querySelectorAll(".owned").forEach((input) => {
      input.onchange = () => {
        const value = parseInt(input.value.replace(/\D/g, ""), 10);
        if (isNaN(value)) delete state.owned[input.dataset.id]; else state.owned[input.dataset.id] = value;
        save(); render();
      };
    });
    el.ingBody.querySelectorAll("[data-eff-place]").forEach((input) => {
      input.onchange = () => { setLocationEffectiveness(input.dataset.effPlace, input.value); render(); };
    });
    el.ingBody.querySelectorAll("[data-source-id]").forEach((select) => {
      select.onchange = () => {
        const id = select.dataset.sourceId;
        if (select.value === "craft") {
          // Crafting is a decision about how the item is made, not where it is
          // bought, so it lives in the other store — and the two must not both
          // be set or they contradict each other.
          state.makeChoices[id] = "craft";
          delete state.sourceChoices[id];
        } else {
          if (state.makeChoices[id] === "craft") delete state.makeChoices[id];
          state.sourceChoices[id] = select.value;
        }
        save();
        render();
      };
    });
    document.querySelectorAll("[data-meal-strip]").forEach((button) => {
      button.onclick = () => { state.mealStripHidden = !state.mealStripHidden; save(); render(); };
    });
    document.querySelectorAll("[data-gather-meal]").forEach((box) => {
      box.onchange = () => { state.meals[box.dataset.gatherMeal] = box.checked; save(); renderSetup(); render(); };
    });
    document.querySelectorAll("[data-buy-id]").forEach((input) => {
      input.onchange = () => {
        const id = input.dataset.buyId;
        const perK = Number(input.value);
        const cur = (document.querySelector(`[data-buy-cur="${id}"]`) || {}).value || "ap";
        if (Number.isFinite(perK) && perK > 0) state.buyRates[id] = { perK, currency: cur };
        else delete state.buyRates[id];
        save(); render();
      };
    });
    document.querySelectorAll("[data-buy-cur]").forEach((select) => {
      select.onchange = () => {
        const id = select.dataset.buyCur;
        const existing = state.buyRates[id];
        const input = document.querySelector(`[data-buy-id="${id}"]`);
        const perK = existing ? existing.perK : Number(input && input.value);
        if (Number.isFinite(perK) && perK > 0) { state.buyRates[id] = { perK, currency: select.value }; save(); render(); }
      };
    });
    document.querySelectorAll("[data-fish-method]").forEach((radio) => {
      radio.onchange = () => { if (radio.checked) { state.fishMethods[radio.dataset.fishMethod] = radio.value; save(); render(); } };
    });
    document.querySelectorAll("[data-drink-id]").forEach((radio) => {
      radio.onchange = () => { if (radio.checked) { state.drinkChoices[radio.dataset.drinkId] = radio.value; save(); render(); } };
    });
    document.querySelectorAll("[data-location-id]").forEach((select) => {
      select.onchange = () => { state.farmLocations[select.dataset.locationId] = select.value; save(); render(); };
    });
    el.tree.innerHTML = treeHtml(tree);

    state.lastPlan = {
      generatedAt: new Date().toISOString(),
      goal: { id: goal.id, name: goal.name, quantity: state.qty },
      profile: { enabledEffects: [...state.enabled], meals: state.meals, infrastructure: state.infra, assumptions: state.overrides },
      economics: { craftSilver, vendorSilver, outputSell, rawSellOpportunity: rawSellValue, economicNetSilver: trueNet, tradeGoldEquivalent: tradeGoldEq, farmGoldEquivalent: farmGoldEq },
      ingredients: rows.map((row) => ({ id: row.item.id, name: row.item.name, need: row.leaf.total, owned: row.owned, missing: row.missing, route: row.route.type, detail: row.route.detail })),
    };
  }

  function profileRows() {
    const map = new Map();
    for (const effect of BASE_EFFECTS) {
      const key = effect.family || effect.id;
      if (!map.has(key)) map.set(key, { key, ids: [], name: effect.name, kind: effect.kind, plain: [] });
      const row = map.get(key);
      row.ids.push(effect.id);
      if (effect.plain && !row.plain.includes(effect.plain)) row.plain.push(effect.plain);
    }
    return [...map.values()];
  }
  function perkArea(row) {
    const effects = BASE_EFFECTS.filter((effect) => row.ids.includes(effect.id));
    const types = effects.map((effect) => effect.type);
    if (types.some((type) => type.includes("craft") || type === "cook_save")) return "Workshop and cooking";
    if (types.some((type) => type.includes("sale"))) return "Selling";
    if (types.some((type) => type.includes("net") || type === "fn_bonus" || type === "ln_bonus")) return "Fishing";
    if (types.some((type) => type.includes("lemonade") || type.includes("ap_items") || type.includes("cider") || type.includes("stamina"))) return "Exploring and drinks";
    if (types.includes("iron_depot")) return "Farm infrastructure";
    return "Special drops";
  }
  // What a capture of the farm page says each building makes, in Setup's own
  // units: [setting, amount, building, what it is].
  function farmProduction() {
    const infra = (state.account && state.account.infrastructure) || {};
    const n = (v) => { const raw = v && typeof v === "object" ? v.value : v; if (raw == null || raw === "") return null; const x = Number(raw); return Number.isFinite(x) ? x : null; };
    const at = (building, key) => n((infra[building] || {})[key]);
    return [
      ["woodHour", at("sawmill", "wood"), "Sawmill", "Wood / hr"],
      ["boardHour", at("sawmill", "boards"), "Sawmill", "Boards / hr"],
      ["steelHour", at("steelworks", "steel"), "Steelworks", "Steel / hr"],
      ["wireHour", at("steelworks", "wire"), "Steelworks", "Steel Wire / hr"],
      ["strawTen", at("hayField", "straw"), "Hay Field", "Straw / 10 min"],
      ["stoneTen", at("quarry", "stone"), "Quarry", "Stone / 10 min"],
      ["coalHour", at("quarry", "coalHourly"), "Quarry", "Coal / hr"],
    ].filter((row) => row[1] != null);
  }
  // A new set of farm numbers fills any production number still at 0, once.
  // "New" is judged by the numbers themselves, not by which capture brought
  // them: the extension once filed the farm page as "unknown", and Setup,
  // waiting for a capture called "farm", never filled in. A number you typed
  // is left alone; "Use my farm's numbers" replaces them all.
  function fillFarmProduction(overwrite) {
    const production = farmProduction();
    if (!production.length) return 0;
    const signature = production.map(([key, value]) => key + "=" + value).join(";");
    if (!overwrite && state.infra.farmFilledFrom === signature) return 0;
    let changed = 0;
    for (const [key, value] of production) {
      if ((overwrite || !Number(state.infra[key])) && state.infra[key] !== value) { state.infra[key] = value; changed += 1; }
    }
    state.infra.farmFilledFrom = signature;
    save();
    return changed;
  }

  function renderSetup() {
    fillFarmProduction(false);
    const rows = profileRows();
    const groups = {};
    rows.forEach((row) => { (groups[perkArea(row)] ||= []).push(row); });
    $("perkGroups").innerHTML = Object.entries(groups).map(([name, groupRows]) => `<section class="perk-group"><h2>${esc(name)}</h2>${groupRows.map((row) => {
      const checked = row.ids.every((id) => state.enabled.has(id));
      const tier = PERK_TIERS[row.key];
      if (tier) {
        const level = tierLevel(row.key);
        const name = row.name.replace(/\s+I-IV$/, "");
        const pct = Math.round(tierValue(row.key, level) * 100);
        const picks = TIER_NAMES.map((label, i) => `<button type="button" class="tier-btn${level === i ? " on" : ""}" data-tier="${esc(row.key)}" data-level="${i}" aria-pressed="${level === i}">${label}</button>`).join("");
        return `<div class="perk-row tiered"><span class="tier-spacer"></span><span><span class="perk-head">${perkArt(row)}<span><strong>${esc(name)}</strong><small>${esc(row.kind || "Bonus")} · highest tier you have</small></span></span><span class="tier-pick" role="group" aria-label="${esc(name)} tier">${picks}</span><p>${level ? esc(tier.text(pct)) : "Off."}</p></span></div>`;
      }
      return `<label class="perk-row"><input type="checkbox" data-effect-family="${esc(row.key)}" ${checked ? "checked" : ""}><span><span class="perk-head">${perkArt(row)}<span><strong>${esc(row.name)}</strong><small>${esc(row.kind || "Bonus")}</small></span></span><p>${row.plain.map(esc).join(" ")}</p></span></label>`;
    }).join("")}</section>`).join("");
    document.querySelectorAll("[data-tier]").forEach((button) => {
      button.onclick = () => {
        const id = button.dataset.tier;
        const level = Number(button.dataset.level) || 0;
        if (level > 0) { state.enabled.add(id); state.perkTiers[id] = level; }
        else { state.enabled.delete(id); delete state.perkTiers[id]; }
        save(); renderSetup(); render();
      };
    });
    document.querySelectorAll("[data-effect-family]").forEach((input) => {
      input.onchange = () => {
        const row = rows.find((candidate) => candidate.key === input.dataset.effectFamily);
        row.ids.forEach((id) => input.checked ? state.enabled.add(id) : state.enabled.delete(id));
        save(); renderSetup(); render();
      };
    });
    const enabledRows = rows.filter((row) => row.ids.every((id) => state.enabled.has(id))).length;
    $("perkCount").textContent = `${enabledRows}/${rows.length}`;
    $("profileSummary").innerHTML = `<span class="profile-score"><b>${enabledRows}</b> of ${rows.length} permanent bonuses active</span>`;

    const infraCards = [
      { title: "Iron Depot", art: itemByName("Iron"), body: "Auto-buys Iron and Nails with silver, so you never need to go and get them.", controls: `<label class="inline-toggle"><input type="checkbox" data-effect-direct="iron_depot" ${state.enabled.has("iron_depot") ? "checked" : ""}> I own Iron Depot</label>` },
      { title: "Sawmill", art: itemByName("Wood"), body: "Wood and Boards arrive every hour. Hickory Omelette adds 20% every 10 minutes for an hour.", controls: `<label class="inline-toggle"><input type="checkbox" data-infra="sawmillWood" ${state.infra.sawmillWood ? "checked" : ""}> Cover Wood</label><label class="inline-toggle"><input type="checkbox" data-infra="sawmillBoard" ${state.infra.sawmillBoard ? "checked" : ""}> Cover Boards</label><label class="mini-field">Useful Wood/hr<input type="number" min="0" data-infra-number="woodHour" value="${clean(state.infra.woodHour)}"></label><label class="mini-field">Useful Boards/hr<input type="number" min="0" data-infra-number="boardHour" value="${clean(state.infra.boardHour)}"></label>` },
      { title: "Inventory cap", art: itemByName("Wooden Box"), body: "Anything over your cap is lost when it is collected.", controls: `<label class="mini-field">Your cap per item<input type="number" min="0" data-infra-number="inventoryCap" value="${clean(state.infra.inventoryCap)}"></label>` },
      { title: "Steel works", art: itemByName("Steel"), body: "Steel and Steel Wire are made on their own. Wire comes out at about a third of the Steel rate.", controls: `<label class="inline-toggle"><input type="checkbox" data-infra="forgeSteel" ${state.infra.forgeSteel ? "checked" : ""}> Cover Steel</label><label class="inline-toggle"><input type="checkbox" data-infra="forgeWire" ${state.infra.forgeWire ? "checked" : ""}> Cover Steel Wire</label><label class="mini-field">Steel/hr<input type="number" min="0" data-infra-number="steelHour" data-fills="wireHour" value="${clean(state.infra.steelHour)}"></label><label class="mini-field">Steel Wire/hr<input type="number" min="0" data-infra-number="wireHour" value="${clean(state.infra.wireHour)}"></label>` },
      { title: "Hay Field", art: itemByName("Straw"), body: "Straw arrives every 10 minutes.", controls: `<label class="inline-toggle"><input type="checkbox" data-infra="hayStraw" ${state.infra.hayStraw ? "checked" : ""}> Cover Straw</label><label class="mini-field">Straw / 10 min<input type="number" min="0" data-infra-number="strawTen" value="${clean(state.infra.strawTen)}"></label>` },
      { title: "Quarry", art: itemByName("Stone"), body: "Stone arrives every 10 minutes. Coal only comes now and then, so it has its own switch.", controls: `<label class="inline-toggle"><input type="checkbox" data-infra="quarryStone" ${state.infra.quarryStone ? "checked" : ""}> Cover Stone</label><label class="inline-toggle"><input type="checkbox" data-infra="quarryCoal" ${state.infra.quarryCoal ? "checked" : ""}> Cover Coal too</label><label class="mini-field">Stone / 10 min<input type="number" min="0" data-infra-number="stoneTen" value="${clean(state.infra.stoneTen)}"></label><label class="mini-field">Average Coal/hr<input type="number" min="0" data-infra-number="coalHour" value="${clean(state.infra.coalHour)}"></label>` },
    ];
    const production = farmProduction();
    const farmNote = production.length
      ? `<div class="farm-capture"><div><strong>From your farm</strong><span>${production.map(([, value, building, what]) => `${esc(building)} ${fmt(value)} ${esc(what)}`).join(" · ")}</span></div><button type="button" class="quiet-button" data-use-farm>Use my farm's numbers</button></div>`
      : "";
    $("infraGrid").innerHTML = farmNote + infraCards.map((card) => `<article class="infra-card"><div class="infra-title">${itemImg(card.art, "meal-art", card.title)}<div><h3>${card.title}</h3></div></div><p>${card.body}</p><div class="infra-controls">${card.controls}</div></article>`).join("");
    document.querySelectorAll("[data-infra]").forEach((input) => { input.onchange = () => { state.infra[input.dataset.infra] = input.checked; save(); render(); }; });
    const useFarm = document.querySelector("[data-use-farm]");
    if (useFarm) useFarm.onclick = () => { fillFarmProduction(true); renderSetup(); render(); };
    document.querySelectorAll("[data-infra-number]").forEach((input) => {
      input.onchange = () => {
        state.infra[input.dataset.infraNumber] = Number(input.value || 0);
        // Steel Wire runs at about a third of Steel, measured by the owner at
        // 1,500/hr against 4,500. Filling it in saves entering the same thing
        // twice, and it stays editable for anyone whose ratio differs.
        const fills = input.dataset.fills;
        if (fills && !Number(state.infra[fills] || 0)) {
          state.infra[fills] = Math.round(Number(input.value || 0) / 3);
        }
        save();
        renderSetup();
        render();
      };
    });
    document.querySelectorAll("[data-effect-direct]").forEach((input) => { input.onchange = () => { input.checked ? state.enabled.add(input.dataset.effectDirect) : state.enabled.delete(input.dataset.effectDirect); save(); renderSetup(); render(); }; });

    $("mealGrid").innerHTML = MEALS.map((meal) => {
      const item = itemByName(meal.name) || (meal.img ? { name: meal.name, img: meal.img } : null);
      return `<label class="meal-card ${state.meals[meal.id] ? "active" : ""}"><input type="checkbox" data-meal="${meal.id}" ${state.meals[meal.id] ? "checked" : ""}>${itemImg(item, "meal-art", meal.name)}<span><small>${esc(meal.area)}</small><strong>${esc(meal.name)}</strong><b>${esc(meal.effect)}</b><p>${esc(meal.calc)}</p></span></label>`;
    }).join("");
    document.querySelectorAll("[data-meal]").forEach((input) => { input.onchange = () => { state.meals[input.dataset.meal] = input.checked; save(); renderSetup(); render(); }; });

    // The Acorn Pie sample form and the editable "numbers behind the plan"
    // were tools for building this site, not for players, and are gone.
  }

  function accountScalar(value) {
    return value === null || value === undefined || value === "" ? "Unknown" : fmt(Number(value));
  }

  function validAccountSnapshot(value) {
    return value && typeof value === "object" && value.schemaVersion === "farmrpg-account-snapshot-v1"
      && value.levels && value.balances && value.quests && Array.isArray(value.inventory);
  }

  function enrichProfileCapture(capture) {
    const shared = window.ImporterShared;
    if (!capture || capture.schema !== "farmrpg-page-capture-v1"
      || !capture.visibleText || !shared || typeof shared.parseProfilePage !== "function") return capture;
    const parsed = shared.parseProfilePage(capture.visibleText.split(/\n/).map((line) => line.trim()).filter(Boolean), capture.visibleText);
    capture.fields ||= {};
    capture.fields.player ||= {};
    const evidence = (value, confidence) => ({ value, raw: String(value), confidence });
    if (capture.pageType === "profile") {
      if (parsed.player.name) capture.fields.player.name = evidence(parsed.player.name, "inferred-page-section");
      if (parsed.player.farmName) capture.fields.player.farmName = evidence(parsed.player.farmName, "visible-label");
      if (parsed.player.accountCreated) capture.fields.player.accountCreated = evidence(parsed.player.accountCreated, "inferred-page-section");
    }
    if (parsed.activeEffects.length) {
      capture.fields.activeEffects = parsed.activeEffects.map((effect) => ({
        name: effect.name,
        uses: effect.uses ? evidence(Number(String(effect.uses).replace(/,/g, "")), "visible-label") : null,
        remaining: effect.remaining,
        confidence: "visible-label",
      }));
    }
    const infra = capture.fields.infrastructure;
    for (const name of ["orchard", "vineyard"]) {
      if (infra && infra[name] && infra[name].notes && infra[name].notes.confidence === "unparsed-text") delete infra[name];
    }
    return capture;
  }

  function enrichTowerCapture(capture) {
    const shared = window.ImporterShared;
    if (!capture || capture.schema !== "farmrpg-page-capture-v1" || capture.pageType !== "tower"
      || !capture.visibleText || !shared || typeof shared.parseTowerPage !== "function") return capture;
    const parsed = shared.parseTowerPage(capture.visibleText.split(/\n/).map((line) => line.trim()).filter(Boolean), capture.visibleText);
    const evidence = (raw, confidence = "visible-label") => {
      if (raw === null || raw === undefined || raw === "") return null;
      const compact = String(raw).replace(/,/g, "").match(/^([\d.]+)([KMBT])?$/i);
      if (!compact) return { value: raw, raw: String(raw), confidence };
      const powers = { K: 1e3, M: 1e6, B: 1e9, T: 1e12 };
      const value = Number(compact[1]) * (compact[2] ? powers[compact[2].toUpperCase()] : 1);
      return { value, raw: String(raw), confidence };
    };
    capture.fields ||= {};
    capture.fields.levels ||= {};
    capture.fields.towerProgress = {
      currentLevel: evidence(parsed.currentLevel),
      ascensionKnowledge: evidence(parsed.ascensionKnowledge),
      dailySilver: evidence(parsed.dailySilver),
      nextLevel: evidence(parsed.nextLevel),
      nextAkCost: evidence(parsed.nextAkCost),
      nextSilverCost: evidence(parsed.nextSilverCost),
      nextMegaMasteries: evidence(parsed.nextMegaMasteries),
      nextRewards: parsed.nextRewards.map((reward) => ({ name: reward.name, quantity: evidence(reward.quantity) })),
      history: parsed.history.map((entry) => ({
        level: evidence(entry.level),
        date: entry.date,
        current: entry.current,
        rewards: entry.rewards.map((reward) => ({ name: reward.name, quantity: evidence(reward.quantity) })),
      })),
    };
    if (capture.fields.towerProgress.currentLevel) capture.fields.levels.tower = capture.fields.towerProgress.currentLevel;
    return capture;
  }

  function enrichMasteryCapture(capture) {
    const shared = window.ImporterShared;
    if (!capture || capture.schema !== "farmrpg-page-capture-v1" || capture.pageType !== "mastery"
      || !capture.visibleText || !shared || typeof shared.parseMasteryPage !== "function") return capture;
    const parsed = shared.parseMasteryPage(capture.visibleText.split(/\n/).map((line) => line.trim()).filter(Boolean), capture.visibleText);
    const evidence = (raw, confidence = "visible-label") => {
      if (raw === null || raw === undefined || raw === "") return null;
      const numeric = String(raw).replace(/,/g, "");
      return { value: /^\d+(?:\.\d+)?$/.test(numeric) ? Number(numeric) : raw, raw: String(raw), confidence };
    };
    capture.fields ||= {};
    if (capture.fields.towerProgress === null) delete capture.fields.towerProgress;
    capture.fields.masteryStats = {
      mastered: evidence(parsed.stats.mastered),
      grandMastered: evidence(parsed.stats.grandMastered),
      megaMastered: evidence(parsed.stats.megaMastered),
    };
    capture.fields.masteries = parsed.masteries.map((entry) => ({
      itemName: entry.itemName,
      masteryCount: evidence(entry.masteryCount),
      masteryLevel: entry.masteryLevel,
      mastered: entry.mastered,
      grandMastery: entry.grandMastery,
      megaMastery: entry.megaMastery,
      towerRequirement: null,
      progressCurrent: evidence(entry.progressCurrent),
      progressTarget: evidence(entry.progressTarget),
      progressPercent: evidence(entry.progressPercent),
      completed: entry.completed,
      confidence: "visible-label",
    }));
    return capture;
  }

  function enrichQuestCapture(capture) {
    const shared = window.ImporterShared;
    if (!capture || capture.schema !== "farmrpg-page-capture-v1" || !String(capture.pageType || "").startsWith("quests")
      || !capture.visibleText || !shared || typeof shared.parseQuestDashboard !== "function") return capture;
    const lines = capture.visibleText.split(/\n/).map((line) => line.trim()).filter(Boolean);
    const completed = typeof shared.parseCompletedQuestPage === "function"
      ? shared.parseCompletedQuestPage(lines, capture.visibleText) : { quests: [] };
    if (completed.quests.length) {
      const evidence = (raw, confidence = "visible-label") => {
        if (raw === null || raw === undefined || raw === "") return null;
        const numeric = String(raw).replace(/,/g, "");
        return { value: typeof raw === "boolean" ? raw : (/^\d+(?:\.\d+)?$/.test(numeric) ? Number(numeric) : raw), raw: String(raw), confidence };
      };
      capture.pageType = "quests-completed";
      capture.pageLabel = "Completed Requests";
      capture.fields ||= {};
      capture.fields.questStats ||= {};
      for (const key of Object.keys(completed.stats)) {
        const value = evidence(completed.stats[key]);
        if (value) capture.fields.questStats[key] = value;
      }
      capture.fields.quests = completed.quests.map((quest) => ({
        ...quest,
        communityCompletions: quest.communityCompletions === null ? null : Number(String(quest.communityCompletions).replace(/,/g, "")),
        communityCompletionPercent: quest.communityCompletionPercent === null ? null : Number(quest.communityCompletionPercent),
      }));
      capture.warnings ||= [];
      if (completed.stats.completedHistoryTruncated && !capture.warnings.some((warning) => /completed request history was truncated/i.test(warning))) {
        capture.warnings.push("Completed request history was truncated by the collector; missing older titles remain unknown.");
      }
      return capture;
    }
    const parsed = shared.parseQuestDashboard(lines, capture.visibleText);
    if (!parsed.quests.length) return capture;
    const evidence = (raw, confidence = "visible-label") => {
      if (raw === null || raw === undefined || raw === "") return null;
      const numeric = String(raw).replace(/,/g, "");
      return { value: /^\d+(?:\.\d+)?$/.test(numeric) ? Number(numeric) : raw, raw: String(raw), confidence };
    };
    capture.fields ||= {};
    capture.fields.questStats = {};
    for (const key of Object.keys(parsed.stats)) {
      const value = evidence(parsed.stats[key]);
      if (value) capture.fields.questStats[key] = value;
    }
    capture.fields.quests = parsed.quests.map((quest) => ({
      ...quest,
      progressPercent: evidence(quest.progressPercent),
    }));
    return capture;
  }

  function enrichPerkCapture(capture) {
    const shared = window.ImporterShared;
    if (!capture || capture.schema !== "farmrpg-page-capture-v1" || capture.pageType !== "perks"
      || !capture.visibleText || !shared || typeof shared.parsePerkPage !== "function") return capture;
    const parsed = shared.parsePerkPage(capture.visibleText.split(/\n/).map((line) => line.trim()).filter(Boolean), capture.visibleText);
    const evidence = (raw, confidence = "visible-label") => {
      if (raw === null || raw === undefined || raw === "") return null;
      const numeric = String(raw).replace(/,/g, "");
      return { value: /^\d+(?:\.\d+)?$/.test(numeric) ? Number(numeric) : raw, raw: String(raw), confidence };
    };
    capture.fields ||= {};
    const existing = new Map((capture.fields.perks || []).map((perk) => [String(perk.name || "").toLowerCase(), perk]));
    capture.fields.perkStats = {};
    for (const key of Object.keys(parsed.stats)) {
      const value = evidence(parsed.stats[key]);
      if (value) capture.fields.perkStats[key] = value;
    }
    capture.fields.perks = parsed.perks.map((perk) => {
      const prior = existing.get(perk.name.toLowerCase()) || {};
      const inferredOwned = typeof prior.owned === "boolean" ? prior.owned
        : (typeof shared.inferPerkOwnership === "function" ? shared.inferPerkOwnership(prior.domEvidence) : null);
      return {
        ...perk,
        owned: inferredOwned,
        towerRequirement: evidence(perk.towerRequirement),
        domEvidence: prior.domEvidence || null,
      };
    });
    return capture;
  }

  function enrichFarmSupplyCapture(capture) {
    const shared = window.ImporterShared;
    const isSupply = capture && (capture.pageType === "farm-supply" || /\/supply\.php(?:$|#)/i.test(String(capture.url || "")));
    if (!isSupply || capture.schema !== "farmrpg-page-capture-v1" || !capture.visibleText
      || !shared || typeof shared.parseFarmSupplyOverview !== "function") return capture;
    const parsed = shared.parseFarmSupplyOverview(capture.visibleText.split(/\n/).map((line) => line.trim()).filter(Boolean), capture.visibleText);
    const evidence = (raw, confidence = "visible-label") => {
      if (raw === null || raw === undefined || raw === "") return null;
      const numeric = String(raw).replace(/,/g, "");
      return { value: /^\d+(?:\.\d+)?$/.test(numeric) ? Number(numeric) : raw, raw: String(raw), confidence };
    };
    capture.pageType = "farm-supply";
    capture.pageLabel = "Farm Supply";
    capture.fields ||= {};
    delete capture.fields.quests;
    capture.fields.capacity ||= {};
    capture.fields.balances ||= {};
    if (parsed.capacityMax) capture.fields.capacity.inventoryMaximum = evidence(parsed.capacityMax);
    if (parsed.staminaMax) capture.fields.balances.staminaMaximum = evidence(parsed.staminaMax);
    capture.fields.supplyStats = {};
    for (const key of Object.keys(parsed.supplyStats)) {
      const value = evidence(parsed.supplyStats[key]);
      if (value) capture.fields.supplyStats[key] = value;
    }
    capture.fields.infrastructure ||= {};
    for (const [building, values] of Object.entries(parsed.infrastructure)) {
      capture.fields.infrastructure[building] = {};
      for (const [key, raw] of Object.entries(values)) capture.fields.infrastructure[building][key] = evidence(raw);
    }
    // Repair captures made by the first Supply-aware collector, where four
    // capacity cards included their "Current ..." subtitle in the name.
    capture.fields.farmSupply = (capture.fields.farmSupply || []).map((entry) => {
      const match = String(entry.name || "").match(/^(\+\d+ (?:Inventory Cap|Max Stamina|Max Mailbox|Active Meal Effect))\b/i);
      return match ? { ...entry, name: match[1] } : entry;
    });
    return capture;
  }

  function enrichPetCapture(capture) {
    const isPets = capture && (capture.pageType === "pets" || /\/pets\.php(?:$|#)/i.test(String(capture.url || "")));
    if (!isPets || capture.schema !== "farmrpg-page-capture-v1") return capture;
    capture.pageType = "pets";
    capture.pageLabel = "Pets";
    capture.fields ||= {};
    const pets = capture.fields.pets || [];
    const canonicalSpecies = [
      "Cat", "Dog", "Squirrel", "Owl", "Boar", "Python", "Lemur", "Baboon", "Frog",
      "Hedgehog", "Fox", "Armadillo", "Tarantula", "Rock", "Parrot", "Penguin",
      "Green Dragon", "Red Dragon", "Blue Dragon", "Bear", "Capybara", "Onion", "Seal",
      "Skunk", "Polar Bear", "Hummingbird", "Tiger Shark",
    ];
    const wolfOnlyAvailable = /Available Pets[\s\S]*?\bWolf\b/i.test(String(capture.visibleText || ""));
    if (pets.length === canonicalSpecies.length && wolfOnlyAvailable && pets.every((pet) => !pet.species)) {
      capture.fields.pets = pets.map((pet, index) => ({ ...pet, species: canonicalSpecies[index] }));
    }
    return capture;
  }

  function enrichFriendshipCapture(capture) {
    const shared = window.ImporterShared;
    const isFriendship = capture && (capture.pageType === "friendships" || /\/npclevels\.php(?:$|#)/i.test(String(capture.url || "")));
    if (!isFriendship || capture.schema !== "farmrpg-page-capture-v1" || !shared
      || typeof shared.parseFriendshipPage !== "function") return capture;
    capture.pageType = "friendships";
    capture.pageLabel = "Friendship Levels";
    capture.fields ||= {};
    delete capture.fields.quests;
    const parsed = shared.parseFriendshipPage(String(capture.visibleText || "").split(/\n/).map((line) => line.trim()).filter(Boolean), String(capture.visibleText || ""));
    const evidence = (raw) => raw === null || raw === undefined ? null : ({
      value: Number(String(raw).replace(/,/g, "")), raw: String(raw), confidence: "visible-label",
    });
    capture.fields.friendships = parsed.friendships.map((entry) => ({
      name: entry.name,
      level: evidence(entry.level),
      nextRewardLevel: evidence(entry.nextRewardLevel),
      townsfolkOfDay: entry.townsfolkOfDay,
      confidence: entry.confidence,
    }));
    return capture;
  }

  function enrichKitchenCapture(capture) {
    const shared = window.ImporterShared;
    const isKitchen = capture && (capture.pageType === "kitchen" || /\/kitchen\.php(?:$|#)/i.test(String(capture.url || "")));
    if (!isKitchen || capture.schema !== "farmrpg-page-capture-v1" || !shared
      || typeof shared.parseKitchenPage !== "function") return capture;
    capture.pageType = "kitchen";
    capture.pageLabel = "My Kitchen";
    capture.fields ||= {};
    delete capture.fields.quests;
    const parsed = shared.parseKitchenPage(String(capture.visibleText || "").split(/\n/).map((line) => line.trim()).filter(Boolean), String(capture.visibleText || ""));
    const evidence = (raw) => raw === null || raw === undefined ? null : ({
      value: Number(String(raw).replace(/,/g, "")), raw: String(raw), confidence: "visible-label",
    });
    capture.fields.levels ||= {};
    if (parsed.cookingLevel) capture.fields.levels.cooking = evidence(parsed.cookingLevel);
    capture.fields.kitchenStats = {};
    for (const key of ["ovensOwned", "emptyOvens", "maximumOvensAvailable", "nextOvenCookingLevel", "fruitPunchLeft"]) {
      if (parsed[key]) capture.fields.kitchenStats[key] = evidence(parsed[key]);
    }
    return capture;
  }

  function enrichInventoryCapture(capture) {
    const shared = window.ImporterShared;
    if (!capture || capture.schema !== "farmrpg-page-capture-v1" || capture.pageType !== "inventory"
      || !capture.visibleText || !shared || typeof shared.parseInventoryPage !== "function") return capture;
    const parsed = shared.parseInventoryPage(capture.visibleText.split(/\n/).map((line) => line.trim()).filter(Boolean), capture.visibleText);
    const evidence = (raw, confidence) => {
      const plain = String(raw).replace(/,/g, "");
      const value = /^\d+$/.test(plain) ? Number(plain) : raw;
      return { value, raw: String(raw), confidence };
    };
    capture.fields ||= {};
    const standalone = (capture.fields.consumables || []).filter((entry) => entry.kind !== "meal");
    capture.fields.inventory = parsed.inventory.map((entry) => ({
      name: entry.name,
      quantity: evidence(entry.quantity, entry.confidence || "visible-label"),
      capacity: entry.atCapacity && parsed.capacityMax ? evidence(parsed.capacityMax, "visible-label") : null,
      locked: null,
      itemId: null,
      confidence: entry.confidence || "visible-label",
    }));
    capture.fields.consumables = standalone.concat(parsed.consumables.map((entry) => ({
      name: entry.name,
      quantity: evidence(entry.quantity, entry.confidence || "visible-label"),
      kind: "meal",
      confidence: entry.confidence || "visible-label",
    })));
    capture.fields.masteries = parsed.masteries.map((entry) => ({
      itemName: entry.itemName,
      masteryCount: null,
      masteryLevel: entry.status,
      grandMastery: /^Grand Mastered$/i.test(entry.status) ? true : null,
      megaMastery: /^Mega Mastered$/i.test(entry.status) ? true : null,
      towerRequirement: null,
      confidence: entry.confidence || "visible-label",
    }));
    capture.fields.capacity ||= {};
    if (parsed.capacityMax) capture.fields.capacity.inventoryMaximum = evidence(parsed.capacityMax, "visible-label");
    capture.fields.inventoryStats ||= {};
    if (parsed.inventoryStats.uniqueItems) capture.fields.inventoryStats.uniqueItems = evidence(parsed.inventoryStats.uniqueItems, "visible-label");
    if (parsed.inventoryStats.totalItems) capture.fields.inventoryStats.totalItems = evidence(parsed.inventoryStats.totalItems, "visible-label");
    return capture;
  }

  function enrichCapture(capture) {
    if (capture && capture.fields && capture.fields.towerProgress === null) delete capture.fields.towerProgress;
    return enrichKitchenCapture(enrichFriendshipCapture(enrichPetCapture(enrichFarmSupplyCapture(enrichPerkCapture(enrichQuestCapture(enrichMasteryCapture(enrichTowerCapture(enrichInventoryCapture(enrichProfileCapture(capture))))))))));
  }

  // One line: whose farm is loaded and when. What it holds is applied as it
  // arrives, so there is nothing to review or confirm.
  function renderAccount() {
    const snapshot = state.account;
    $("accountEmpty").classList.toggle("hidden", !!snapshot);
    $("accountResult").classList.toggle("hidden", !snapshot);
    if (!snapshot) return;
    const name = snapshot.player && snapshot.player.name;
    const when = Date.parse(state.extensionConnectedAt || snapshot.generatedAt || "");
    const items = (snapshot.inventory || []).filter((row) => isRealItem(row.name || row.itemName)).length;
    const bits = [items ? `${fmt(items)} items` : "", Number.isFinite(when) ? `updated ${new Date(when).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}` : ""].filter(Boolean);
    $("accountLoaded").innerHTML = `<strong>${name ? `${esc(name)}'s farm is loaded` : "Your farm is loaded"}</strong>${bits.length ? `<span>${bits.join(" · ")}</span>` : ""}`;
  }


  const PUMPKIN_JUICE_MMS = new Set(["Pitchfork", "Salt", "Fancy Pan Flute", "Wrench", "Red Trunk", "Water Lily", "Wizard Hat", "Jade Charm", "Fancy Guitar"]);

  // The imported mastery file is the base, because it is complete. A capture
  // taken AFTER it should still update the items it covers — treating the file
  // as absolute meant re-capturing masteries could never change anything, and
  // it silently did nothing. An older capture is ignored, so a stale one can
  // never walk the numbers backwards.
  function masteryRowsToApply() {
    const rows = (state.account && state.account.masteries) || [];
    if (!rows.length) return [];
    if (!PERSONAL.authoritativeMasteries) return rows;
    const fileAt = Date.parse(PERSONAL.capturedAt || "");
    if (!Number.isFinite(fileAt)) return [];
    // Judge each row by when its own page was read. The snapshot's generatedAt
    // is when the extension last rebuilt it, which moves on every capture of
    // any page — so a fresh mastery read and a weeks-old one looked alike.
    const fallback = Date.parse((state.account && state.account.generatedAt) || "");
    return rows.filter((row) => {
      const readAt = Date.parse(row.capturedAt || "");
      return (Number.isFinite(readAt) ? readAt : fallback) > fileAt;
    });
  }
  // When the Tower numbers were last actually refreshed: the newest capture
  // that beat the mastery file, or the file itself.
  function masteryUpdatedAt() {
    const fileAt = Date.parse(PERSONAL.capturedAt || "");
    const newest = masteryRowsToApply().reduce((latest, row) => Math.max(latest, Date.parse(row.capturedAt || "") || 0), 0);
    if (newest > (Number.isFinite(fileAt) ? fileAt : 0)) return new Date(newest).toISOString();
    return PERSONAL.capturedAt || null;
  }

  function towerMasteryMap() {
    const values = new Map(Object.entries(PERSONAL.masteries || {}).map(([name, value]) => [name.toLowerCase(), Number(value) || 0]));
    for (const row of masteryRowsToApply()) {
      // Older captures kept the Tower floor on the name: "Glass Jar 287".
      const name = String(row.itemName || "").trim().replace(/\s+\d{3}(?:\s*\/\s*\d{3})*\s*$/, "");
      if (!name) continue;
      const level = String(row.masteryLevel || row.status || "");
      let value = Number(row.masteryCount ?? row.progressCurrent);
      const counted = Number.isFinite(value);
      if (row.megaMastery === true || /mega mastered/i.test(level)) value = 1000000;
      else if (!counted && (row.grandMastery === true || /grand mastered/i.test(level))) value = 100000;
      else if (!counted && /mastered/i.test(level)) value = 10000;
      if (!Number.isFinite(value)) continue;
      value = Math.min(1000000, Math.max(0, value));
      // A bare "Grand Mastered" label (the inventory page shows no number)
      // only says "at least 100,000". It must never pull 450,000 down.
      const key = name.toLowerCase();
      values.set(key, counted ? value : Math.max(values.get(key) || 0, value));
    }
    return values;
  }

  const MM_GOAL = 1000000;
  const GM_GOAL = 100000;

  // The floor the player is on. The Mastery History import records it, and a
  // profile or Tower capture reads it off the game; floors only go up, so the
  // higher of the two is right. Every floor below it is cleared.
  function currentTowerFloor() {
    const fromFile = Number(PERSONAL.towerAtCapture || PERSONAL.startFloor) || 0;
    const captured = Number(state.account && state.account.levels && state.account.levels.tower) || 0;
    // No farm and no Tower page seen yet: start at the bottom, not at the
    // author's floor (a fresh download opened on T277).
    return Math.max(fromFile, captured) || 1;
  }

  // Where the Tower's mastery numbers came from, so "did my capture land?" is
  // answered on the page instead of guessed at.
  function masterySourceNote() {
    const fromPage = ((state.account && state.account.masteries) || []).filter((row) => row.sourcePage === "mastery");
    if (!state.account) return "the extension has not reached this page";
    if (!fromPage.length) return "no mastery capture has arrived yet";
    const readAt = fromPage.reduce((latest, row) => Math.max(latest, Date.parse(row.capturedAt || "") || 0), 0);
    const items = `${fmt(fromPage.length)} ${fromPage.length === 1 ? "item" : "items"}`;
    // No built-in export to compare against (a visitor's own farm): the
    // capture is simply the source. Comparing against a missing date is NaN,
    // which used to fall through and call a fresh capture "older".
    const fileAt = Date.parse(PERSONAL.capturedAt || "");
    if (!Number.isFinite(fileAt) || readAt > fileAt) return `from your mastery capture (${items})`;
    const when = new Date(readAt).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
    return `your mastery capture (${when}, ${items}) is older than the mastery export`;
  }

  // Every floor's requirement, in one list. Floors the Tower MM wiki covers
  // (T300–T340) come from it, because it is the only source that says which
  // masteries a floor wants at GRAND level rather than Mega — scoring those
  // against 1m overstates what is actually left. Earlier floors keep the
  // planner's own named Mega Mastery goals.
  function towerRequirements() {
    const progress = towerMasteryMap();
    const floorNow = currentTowerFloor();
    const wikiFloors = new Set((TOWER_FLOORS.floors || []).map((row) => row.floor));
    const rows = [];
    const push = (name, floor, tier, img, methods) => {
      const goal = tier === "gm" ? GM_GOAL : MM_GOAL;
      const current = progress.get(String(name).toLowerCase()) || 0;
      // A floor below the one you are on is cleared in game, whatever its
      // mastery number says here.
      const cleared = floor < floorNow;
      rows.push({
        name, floor, tier, goal, current,
        remaining: cleared ? 0 : Math.max(0, goal - current),
        complete: cleared || current >= goal,
        methods: methods || [],
        img: img || null,
      });
    };
    for (const [name, row] of Object.entries(P.items || {})) {
      if (!row.mastery || row.mastery.towerRequirement == null) continue;
      const floor = Number(row.mastery.towerRequirement);
      if (!Number.isFinite(floor) || wikiFloors.has(floor)) continue;
      push(name, floor, "mm", null, row.mastery.methods);
    }
    for (const floorRow of TOWER_FLOORS.floors || []) {
      const known = (name) => (P.items || {})[name];
      for (const entry of floorRow.gms || []) {
        const item = known(entry.name);
        push(entry.name, floorRow.floor, "gm", entry.img, item && item.mastery && item.mastery.methods);
      }
      for (const entry of floorRow.mms || []) {
        const item = known(entry.name);
        push(entry.name, floorRow.floor, "mm", entry.img, item && item.mastery && item.mastery.methods);
      }
    }
    return rows.sort((a, b) => a.floor - b.floor || a.name.localeCompare(b.name));
  }

  // The owner's own workbook rates every masterable item: a Tower floor when
  // it is a Tower requirement, otherwise how hard it is (1 easy .. 6 extremely
  // hard) or why it is not worth chasing at all. The rail used to say only
  // "No route data for this one yet", which is true but unhelpful.
  const MASTERY_RATING = ((window.FRPG_OWNER_WORKBOOK || {}).masteryFeasibility) || {};
  const RATING_CLASS = {
    "not possible": "blocked", "too expensive": "blocked", "too long / pet": "slow",
    "event": "event", "Event": "event", "event possible": "event",
    "1 easy": "easy", "2 normal": "easy", "3 medium": "mid",
    "4 hard": "hard", "5 very hard": "hard", "6 extremely hard": "hard",
  };
  function masteryRating(name) {
    const row = MASTERY_RATING[name] ||
      MASTERY_RATING[Object.keys(MASTERY_RATING).find((key) => key.toLowerCase() === String(name).toLowerCase())];
    // The workbook says "not possible" for 62 items (every Runestone, Bone
    // Broth...). They can be done - just at a cost nobody pays - so the Tower
    // says that instead (owner's call, 2026-10-08).
    const note = row && row.note === "not possible" ? "too expensive" : row && row.note;
    return note ? { note, kind: RATING_CLASS[note] || "mid" } : null;
  }
  function renderTower() {
    // The top floor is whatever the floor data reaches, so publishing a new
    // block of floors is a data change, not a code change.
    const goal = Math.max(340, ...(TOWER_FLOORS.floors || []).map((row) => row.floor));
    const floorNow = currentTowerFloor();
    const start = Math.max(1, Math.min(goal, state.towerStartChosen ? (Number(state.towerStart) || floorNow) : floorNow));
    document.querySelectorAll("[data-tower-top]").forEach((node) => { node.textContent = `T${goal}`; });
    $("towerStart").max = String(goal);
    // Published so the gather lists can point out the items that serve a Tower
    // mastery as well as the questline being tracked. Rebuilt on every Tower
    // render, which is also when the mastery numbers can have changed.
    window.FRPG_TOWER_NEEDS = towerRequirements();
    const rows = window.FRPG_TOWER_NEEDS.filter((row) => row.floor >= start && row.floor <= goal);
    const floors = new Map();
    for (const row of rows) {
      if (!floors.has(row.floor)) floors.set(row.floor, []);
      floors.get(row.floor).push(row);
    }
    // What you still owe comes first, closest to finished at the top, and
    // anything already done drops to the bottom of its floor.
    for (const items of floors.values()) {
      items.sort((a, b) => Number(a.complete) - Number(b.complete) || a.remaining - b.remaining || a.name.localeCompare(b.name));
    }
    const unfinished = rows.filter((row) => !row.complete);
    const blocked = [...floors].filter(([, items]) => items.some((row) => !row.complete));
    const nextFloor = blocked[0] ? blocked[0][0] : goal;
    const remaining = unfinished.reduce((sum, row) => sum + row.remaining, 0);
    $("towerStart").value = String(start);
    $("towerShowDone").checked = state.towerShowDone;
    $("towerNextFloor").textContent = `T${nextFloor}`;
    const captureDate = PERSONAL.authoritativeMasteries ? masteryUpdatedAt() : state.extensionConnectedAt || state.account && state.account.generatedAt || PERSONAL.capturedAt;
    // With the time: several captures a day all showed the same bare date,
    // so a capture that did land looked like it had not.
    $("towerCaptureAge").textContent = captureDate
      ? `Last updated ${new Date(captureDate).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })} · ${masterySourceNote()}`
      : "No saved progress yet";
    // The named-mastery list only reaches as far as the data does — don't
    // claim a floor range the rows can't back up.
    const namedTop = rows.length ? rows[rows.length - 1].floor : start;
    $("towerSummary").innerHTML = [
      ["Masteries still to finish", `${unfinished.length} / ${rows.length}`, `requirements up to T${namedTop}`],
      ["Floors still blocked", String(blocked.length), `of ${floors.size} in this range`],
      ["Still to make or catch", fmt(remaining), "items across every unfinished mastery"],
      ["Already done", String(rows.length - unfinished.length), `${rows.filter((r) => r.tier === "gm").length} of these only need a Grand Mastery`],
    ].map(([label, value, note]) => `<article><span>${esc(label)}</span><strong>${esc(value)}</strong><small>${esc(note)}</small></article>`).join("");
    const visibleFloors = [...floors].filter(([, items]) => state.towerShowDone || items.some((row) => !row.complete));
    $("towerRail").innerHTML = visibleFloors.length ? visibleFloors.map(([floor, items]) => {
      const complete = items.every((row) => row.complete);
      const isNext = floor === nextFloor;
      return `<article class="tower-floor ${complete ? "is-done" : "is-work"} ${isNext ? "is-next" : ""}"><div class="tower-floor-mark"><span>Floor</span><strong>T${floor}</strong><small>${complete ? "Gate cleared" : `${items.filter((row) => !row.complete).length} left`}</small></div><div class="tower-floor-items">${items.map((row) => {
        const item = itemByName(row.name);
        const percent = Math.min(100, (row.current / row.goal) * 100);
        const tierLabel = row.tier === "gm" ? "Grand Mastery" : "Mega Mastery";
        const method = row.methods.join(" / ");
        const goalLabel = row.tier === "gm" ? "100k" : "1m";
        // Pumpkin Juice only shortens a Mega Mastery.
        const pjGap = row.tier === "mm" && PUMPKIN_JUICE_MMS.has(row.name) && !row.complete ? Math.max(0, 909091 - row.current) : null;
        // Only offer the "open in the planner" click when the planner actually
        // knows the item. Otherwise it looked like a button and did nothing.
        const plannable = !!item;
        const openAttrs = row.complete || !plannable ? "" : ` data-open-item="${esc(row.name)}" data-open-qty="${row.remaining}" tabindex="0" role="button" title="Open ${esc(row.name)} in the calculator"`;
        const rating = row.complete ? null : masteryRating(row.name);
        const noPlan = row.complete || plannable ? "" : `<small class="tower-noplan">No route data for this one yet</small>`;
        const ratingTag = rating ? `<small class="tower-rating is-${rating.kind}">${esc(rating.note)}</small>` : "";
        const art = itemImg(item, "tower-art", row.name, row.img);
        // Which tier the floor wants, and whether a quest is waiting on the
        // same item — both decide whether this is worth doing next.
        const tierTag = `<span class="tower-tier is-${row.tier}" title="${esc(tierLabel)}">${row.tier === "gm" ? "GM" : "MM"}</span>`;
        const needs = row.complete ? null : questNeedsFor(row.name);
        const held = needs ? heldOf(row.name) : null;
        const owed = needs ? Math.max(0, needs.total - (held || 0)) : 0;
        const questTag = needs
          ? `<span class="tower-questtag${owed ? "" : " is-met"}" title="${esc(plural(needs.steps, "quest", "quests"))} asking for ${esc(fmt(needs.total))}${held != null ? `, and you hold ${esc(fmt(held))}` : ""}">${owed ? `Quest ${esc(fmt(owed))}` : "Quest met"}</span>`
          : "";
        return `<div class="tower-mm ${row.complete ? "complete" : "working"}${plannable || row.complete ? "" : " no-plan"}"${openAttrs}>${art}<div class="tower-mm-main"><div class="tower-mm-title"><strong>${esc(row.name)}</strong><span class="tower-mm-tags">${tierTag}${questTag}<span>${esc(method)}</span></span></div><div class="tower-mm-bar"><div class="tower-progress"><i style="width:${percent}%"></i></div><b class="tower-left">${row.complete ? "Done" : `${fmt(row.remaining)} left`}</b></div><div class="tower-mm-numbers"><b>${fmt(row.current)} / ${goalLabel}</b><span>${row.complete ? `${row.tier === "gm" ? "GM" : "MM"} complete` : `${Math.floor(percent)}%`}</span></div>${pjGap !== null ? `<small class="tower-pj">With Pumpkin Juice: ${fmt(pjGap)} more</small>` : ""}${noPlan}${ratingTag}</div></div>`;
      }).join("")}</div></article>`;
    }).join("") : `<div class="tower-all-clear"><strong>Everything in this range is complete.</strong><span>Turn on “Show completed floors” to review the cleared requirements.</span></div>`;

    const connected = !!state.extensionConnectedAt;
    const sync = $("towerSyncState");
    sync.classList.toggle("connected", connected);
    sync.innerHTML = `<span></span><strong>${connected ? "Updating automatically" : "Saved progress"}</strong><small>${connected ? `Refreshed ${new Date(state.extensionConnectedAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}` : ""}</small>`;
    const accountSync = $("extensionStatus");
    if (accountSync) {
      accountSync.classList.toggle("connected", connected);
      accountSync.innerHTML = `<span></span><strong>${connected ? "Extension connected" : "Waiting for extension"}</strong><small>${connected ? "New Farm RPG pages refresh this account automatically." : "Load the extension once, then browse Farm RPG normally."}</small>`;
    }
  }

  function openTowerItem(target) {
    const button = target.closest("[data-open-item]");
    if (!button) return;
    window.FRPG_openItem && window.FRPG_openItem(button.dataset.openItem, button.dataset.openQty);
  }
  $("towerRail").addEventListener("click", (event) => openTowerItem(event.target));
  $("towerRail").addEventListener("keydown", (event) => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); openTowerItem(event.target); } });

  function applyAccountSnapshot() {
    if (!state.account) return;
    let inventoryApplied = 0;
    for (const entry of state.account.inventory || []) {
      if (!isRealItem(entry.name)) continue;
      const id = index.idByName.get(String(entry.name || "").trim().toLowerCase());
      const quantity = Number(entry.quantity);
      if (id && Number.isFinite(quantity) && quantity >= 0) {
        state.owned[id] = quantity;
        inventoryApplied += 1;
      }
    }
    const confirmed = [...(state.account.perks || []), ...(state.account.farmSupply || []), ...(state.account.artifacts || [])]
      .filter((entry) => entry.owned === true).map((entry) => String(entry.name || "").trim().toLowerCase());
    let effectsApplied = 0;
    for (const effect of BASE_EFFECTS) {
      if (confirmed.includes(String(effect.name || "").trim().toLowerCase())) {
        state.enabled.add(effect.id);
        effectsApplied += 1;
      }
    }
    // Tiered perks: the perks page lists "Artisan I" ... "Artisan IV" one by
    // one, each owned or not. The highest owned tier is the one to use. Only
    // a capture that lists the tiers at all can turn one off.
    const perkRows = state.account.perks || [];
    for (const id of Object.keys(PERK_TIERS)) {
      const base = (BASE_EFFECTS.find((effect) => effect.id === id) || {}).name || "";
      const stem = base.replace(/\s+I-IV$/, "").toLowerCase();
      const listed = TIER_NAMES.slice(1).map((roman) => perkRows.find((row) => String(row.name || "").trim().toLowerCase() === `${stem} ${roman.toLowerCase()}`));
      if (!listed.some(Boolean)) continue;
      let level = 0;
      listed.forEach((row, i) => { if (row && row.owned === true) level = i + 1; });
      if (level > 0) { state.enabled.add(id); state.perkTiers[id] = level; effectsApplied += 1; }
      else { state.enabled.delete(id); delete state.perkTiers[id]; }
    }
    if (state.account.infrastructure && state.account.infrastructure.ironDepot === true && !state.enabled.has("iron_depot")) {
      state.enabled.add("iron_depot");
      effectsApplied += 1;
    }
    save();
    renderSetup();
    render();
    return inventoryApplied + effectsApplied;
  }

  $("maxProfile").onclick = () => { state.enabled = new Set(allEffectIds); save(); renderSetup(); render(); };
  $("zeroProfile").onclick = () => { state.enabled.clear(); save(); renderSetup(); render(); };
  if ($("resetAssumptions")) $("resetAssumptions").onclick = () => { state.overrides = {}; save(); renderSetup(); render(); };
  $("includeEvents").onchange = (event) => { state.includeEvents = event.target.checked; save(); render(); };
  if ($("drinkPath")) $("drinkPath").onchange = (event) => { state.drinkPath = event.target.value; save(); render(); };
  if ($("staminaMeasured")) $("staminaMeasured").oninput = (event) => {
    const percent = Number(event.target.value);
    if (event.target.value === "" || !Number.isFinite(percent) || percent <= 0) delete state.overrides.explore_stamina_measured;
    else state.overrides.explore_stamina_measured = Math.min(100, percent) / 100;
    save(); render();
  };
  // The author's account files are an example until someone brings their own
  // farm, and must then drop out entirely. js/account-source.js decides that
  // before this file runs, so a change of owner needs a reload to take effect.
  function accountSourceChanged() {
    const source = window.FRPG_ACCOUNT_SOURCE;
    if (source) source.accountChanged(!!state.account);
  }
  $("accountFile").onchange = async (event) => {
    const files = [...(event.target.files || [])];
    if (!files.length) return;
    try {
      const parsedFiles = await Promise.all(files.map(async (file) => ({ file, parsed: enrichCapture(JSON.parse(await file.text())) })));
      if (parsedFiles.length === 1 && validAccountSnapshot(parsedFiles[0].parsed)) {
        state.account = parsedFiles[0].parsed;
      } else {
        const shared = window.ImporterShared;
        if (!shared || typeof shared.validateCapture !== "function" || typeof shared.mergeCaptures !== "function") {
          throw new Error("The local capture merger did not load.");
        }
        const captures = [];
        const failures = [];
        for (const row of parsedFiles) {
          const checked = shared.validateCapture(row.parsed, row.file.size);
          if (!checked.ok) failures.push(row.file.name + ": " + checked.errors.join(" "));
          else {
            checked.capture._fileName = row.file.name;
            captures.push(checked.capture);
          }
        }
        if (!captures.length) throw new Error(failures.join(" ") || "No valid page captures were selected.");
        state.account = shared.mergeCaptures(captures);
        state.account.legacyV1 = shared.buildLegacyV1(state.account);
        if (failures.length) state.account.warnings.unshift(...failures);
      }
      save();
      applyAccountSnapshot();
      renderAccount();
      accountSourceChanged();
    } catch (error) {
      state.account = null;
      save();
      renderAccount();
      $("accountEmpty").innerHTML = `<strong>Could not load that file.</strong><span>${esc(error.message || error)}</span>`;
    }
    event.target.value = "";
  };
  $("clearAccount").onclick = () => { state.account = null; save(); renderAccount(); accountSourceChanged(); };
  $("towerStart").onchange = (event) => { state.towerStart = Number(event.target.value) || currentTowerFloor(); state.towerStartChosen = true; save(); renderTower(); };
  $("towerShowDone").onchange = (event) => { state.towerShowDone = event.target.checked; save(); renderTower(); };

  window.addEventListener("message", (event) => {
    const message = event.data;
    if (event.source !== window || !message || message.source !== "farmrpg-account-sync" || message.type !== "snapshot") return;
    if (!validAccountSnapshot(message.snapshot)) return;
    state.account = message.snapshot;
    state.extensionConnectedAt = message.syncedAt || new Date().toISOString();
    save();
    accountSourceChanged();
    applyAccountSnapshot();
    renderAccount();
    renderTower();
    if (fillFarmProduction(false)) { renderSetup(); render(); }
  });
  window.postMessage({ source: "farmrpg-calculator", type: "request-snapshot" }, "*");

  // A visible build stamp. Half the "it still does the old thing" reports are a
// browser holding an old copy of a file, and this is the only way to tell.
if ($("footer")) $("footer").innerHTML = "Farm RPG Calculator is a fan-made planner, not affiliated with Farm RPG. Your account data stays in this browser. <span class=\"build-stamp\">Build " + FRPG_BUILD + "</span>";


  renderSetup();
  renderTower();
  // Reopen the item this player last costed. With none saved, Calculate starts
  // empty and offers their own next Tower masteries. It used to open Red Trunk
  // for everyone, which put somebody else's goal on a first visit and meant the
  // empty state could never be reached.
  const last = Number(localStorage.getItem("frpg_last"));
  if (last && index.itemsById.has(last)) pick(last);
  renderHome();
  const viewFromHash = () => {
    // A view may carry a sub-path, as the Items page does: #items/steel-wire.
    const id = location.hash.replace(/^#/, "").split("/")[0];
    return document.getElementById(id)?.classList.contains("view") ? id : "home";
  };
  // gather-model.js loads after this file, so the first render of the home
  // page cannot see it. Redraw once everything is in, and whenever what is
  // being tracked changes.
  window.addEventListener("load", renderStanding);
  window.addEventListener("frpg:tracked-line", renderStanding);
  window.addEventListener("popstate", () => showTab(viewFromHash(), true));
  window.addEventListener("hashchange", () => showTab(viewFromHash(), true));
  // The Tower tab may never be opened, but the gather lists still want to know
  // which items double as Tower masteries.
  try { window.FRPG_TOWER_NEEDS = towerRequirements(); } catch (_) { /* data not ready */ }
  showTab(viewFromHash(), true);
})();


