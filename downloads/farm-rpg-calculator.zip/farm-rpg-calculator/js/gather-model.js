(function () {
  // What is still needed for a tracked questline, netted against what the
  // player holds. Both the Inventory tab and the floating tracker read this,
  // so the two can never disagree about what is left.
  const MODEL = window.FRPG_QUEST_MODEL;
  const ART = window.FRPG_ITEM_ART_HELPER;
  if (!MODEL || !ART) return;

  const itemRows = ((((window.FRPG_DATA || {}).items || {}).items) || []);
  const byId = new Map(itemRows.map((item) => [String(item.id), item]));
  const byName = new Map(itemRows.map((item) => [String(item.name || "").trim().toLowerCase(), item]));
  const keyFor = (name) => String(name || "").trim().toLowerCase();

  function readJson(key) {
    try {
      const raw = localStorage.getItem(key);
      return raw == null ? null : JSON.parse(raw);
    } catch (_) { return null; }
  }

  // What you hold: the latest capture, with anything you typed by hand in
  // Calculate laid on top. It used to be one or the other — a single amount
  // typed in Calculate (Straw, say) hid a 1,200-item capture entirely.
  function inventoryRows() {
    const snapshot = readJson("frpg_account_snapshot_v1");
    const rows = new Map();
    for (const row of (snapshot && snapshot.inventory) || []) {
      const name = row.name || row.itemName || "";
      if (!name || !(Number(row.quantity) > 0) || isDescription(name)) continue;
      rows.set(keyFor(name), { name, quantity: Number(row.quantity), item: byName.get(keyFor(name)) || null });
    }
    const saved = readJson("frpg_owned");
    if (saved && typeof saved === "object" && !Array.isArray(saved)) {
      for (const [id, quantity] of Object.entries(saved)) {
        const item = byId.get(String(id));
        if (!item) continue;
        if (Number(quantity) > 0) rows.set(keyFor(item.name), { name: item.name, quantity: Number(quantity), item });
        else rows.delete(keyFor(item.name));
      }
    }
    return [...rows.values()];
  }

  // Farm RPG prints a description under each item name, and older captures
  // stored those as items: "A blinger for your finger", "Almost transparent",
  // "Adds 100 Stamina". Guessing at their shape kept missing cases — the last
  // one is Title Case with no lowercase word in it. The complete item library
  // makes guessing unnecessary: if Farm RPG has no item by that name, and no
  // artwork was found for it anywhere including the player's own captures,
  // then it is not an item. An item added to the game after the library was
  // built still passes, because a capture brings its picture along.
  function isDescription(name) {
    const text = String(name || "").trim();
    if (!text) return true;
    if (ART.isCurrency(text)) return false;
    return !(ART.isKnownItem ? ART.isKnownItem(text) : (ART.itemFor(text) || ART.urlFor(text)));
  }

  function ignoredCount() {
    const snapshot = readJson("frpg_account_snapshot_v1");
    return ((snapshot && snapshot.inventory) || [])
      .filter((row) => isDescription(row.name || row.itemName || "")).length;
  }

  function ownedMap(rows) {
    const map = new Map();
    for (const row of rows) map.set(keyFor(row.name), (map.get(keyFor(row.name)) || 0) + Number(row.quantity || 0));
    return map;
  }

  function totalsFor(quests) {
    const totals = new Map();
    for (const quest of quests) {
      for (const row of quest.requirements || []) {
        const key = keyFor(row.item);
        if (!key) continue;
        if (!totals.has(key)) totals.set(key, { name: row.item, quantity: 0 });
        totals.get(key).quantity += Number(row.quantity || 0);
      }
    }
    return [...totals.values()];
  }

  function withStock(requirements, have) {
    return requirements.map((row) => {
      const currency = ART.isCurrency(row.name);
      const owned = currency ? null : Number(have.get(keyFor(row.name)) || 0);
      return { ...row, owned, short: Math.max(0, Number(row.quantity || 0) - Number(owned || 0)), currency };
    }).sort((a, b) => Number(b.short > 0) - Number(a.short > 0) || b.short - a.short || a.name.localeCompare(b.name));
  }

  function trackedLine() {
    try { return localStorage.getItem("frpg_tracked_line") || ""; }
    catch (_) { return ""; }
  }

  function hasStoredChoice() {
    try { return localStorage.getItem("frpg_tracked_line") !== null; }
    catch (_) { return false; }
  }

  // The questline the player has started and has the most left to do on. Used
  // when nothing is pinned, so neither view ever opens on an empty picker.
  function busiestLine() {
    const completed = MODEL.completedSet();
    let started = null;
    let anything = null;
    for (const line of MODEL.lines) {
      const steps = MODEL.quests.filter((quest) => quest.line === line.name);
      const left = steps.filter((quest) => !completed.has(MODEL.normalizeTitle(quest.title))).length;
      if (!left) continue;
      if (!anything || left > anything.left) anything = { name: line.name, left };
      if (steps.length - left > 0 && (!started || left > started.left)) started = { name: line.name, left };
    }
    // With no finished quests on record (a fresh copy, or an account whose
    // quest pages were never captured) nothing has been started, so every line
    // ties for "most left" - picking one would only look like real progress.
    if (!started && !completed.size) return "";
    return (started || anything || {}).name || "";
  }

  function plan() {
    const pinned = trackedLine();
    const known = MODEL.lines.some((line) => line.name === pinned);
    // An empty stored value is a deliberate "none" and must be respected;
    // auto-picking is only for a player who has never chosen.
    const clearedOnPurpose = !known && hasStoredChoice() && !pinned;
    const lineName = known ? pinned : (clearedOnPurpose ? "" : busiestLine());
    const stock = inventoryRows();
    if (!lineName) return { lineName: "", auto: !known, stock, remaining: [], next: null, nextRows: [], wholeRows: [] };

    const completed = MODEL.completedSet();
    const remaining = MODEL.quests.filter((quest) => quest.line === lineName && !completed.has(MODEL.normalizeTitle(quest.title)));
    const have = ownedMap(stock);
    return {
      lineName,
      auto: !known,
      stock,
      remaining,
      next: remaining[0] || null,
      nextRows: remaining.length ? withStock(totalsFor([remaining[0]]), have) : [],
      wholeRows: withStock(totalsFor(remaining), have),
    };
  }

  // Where an item comes from, in the player's terms, from the data already
  // loaded — no rates, no invention. Beware: for a meal, growMin is the
  // cooking time, not a growth time, so meals must never read as "Grow".
  function whereFor(name) {
    const index = window.FRPG_INDEX;
    if (!index) return "";
    const id = index.idByName.get(keyFor(name));
    const item = id ? index.itemsById.get(id) : null;
    if (!item) return "";

    const bits = [];
    if (item.craftPrice != null) bits.push("Craft");
    if (item.type === "meal" || item.cookLevel != null) bits.push("Cook");
    else if (item.growMin > 0) bits.push("Grow");

    const sources = index.locsByItem.get(keyFor(item.name)) || [];
    const fishing = [...new Set(sources.filter((row) => row.mode === "fishes").map((row) => row.loc))];
    const exploring = [...new Set(sources.filter((row) => row.mode !== "fishes").map((row) => row.loc))];
    if (fishing.length) bits.push("Fish " + fishing[0] + (fishing.length > 1 ? " +" + (fishing.length - 1) : ""));
    if (exploring.length) bits.push("Explore " + exploring[0] + (exploring.length > 1 ? " +" + (exploring.length - 1) : ""));
    const mines = (((window.FRPG_LOCATION_INTEL || {}).mining || {}).mines) || [];
    const mine = mines.find((row) => (row.items || []).some((entry) => keyFor(entry) === keyFor(item.name)));
    if (mine) bits.push("Mine " + mine.name);

    if (item.buy != null && item.buy > 0) bits.push("Buy " + item.buy.toLocaleString() + "g");
    const market = index.marketByName.get(keyFor(item.name));
    if (market && (market.gold || market.ap || market.oj)) bits.push("Trade");
    return bits.join(" · ");
  }

  // Endgame currency is time, so the most useful thing this app can say is
  // which of the items you already have to gather ALSO finish a Tower mastery.
  // Both numbers are facts already on the page; the overlap is not.
  function towerOverlap(rows) {
    const needs = window.FRPG_TOWER_NEEDS || [];
    if (!needs.length) return [];
    const unfinished = new Map();
    for (const need of needs) {
      if (need.complete) continue;
      const key = keyFor(need.name);
      const seen = unfinished.get(key);
      // Lowest floor first: that is the one it helps you reach next.
      if (!seen || need.floor < seen.floor) unfinished.set(key, need);
    }
    return rows
      .filter((row) => !row.currency && unfinished.has(keyFor(row.name)))
      .map((row) => ({ ...row, tower: unfinished.get(keyFor(row.name)) }))
      .sort((a, b) => a.tower.floor - b.tower.floor || b.short - a.short);
  }

  window.FRPG_GATHER = {
    towerOverlap,
    whereFor, plan, inventoryRows, ignoredCount, trackedLine, hasStoredChoice, busiestLine, keyFor };
})();
