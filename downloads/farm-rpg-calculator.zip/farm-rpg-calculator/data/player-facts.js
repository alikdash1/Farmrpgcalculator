// Empty on purpose: facts about one farm (chests held, buildings, prices) do
// not ship. Game rules the planner needs live in the other data files.
window.FRPG_PLAYER_FACTS = { "schema": "farmrpg-player-facts-v1", "clean": true, "containersHeld": {}, "inventoryCap": null, "farm": {} };