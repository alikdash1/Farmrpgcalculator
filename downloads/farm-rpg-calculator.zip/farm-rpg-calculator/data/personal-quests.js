// Empty on purpose: your finished quests arrive from the extension.
window.FRPG_PERSONAL_QUESTS = { "schema": "farmrpg-personal-quests-v1", "clean": true, "completed": [] };