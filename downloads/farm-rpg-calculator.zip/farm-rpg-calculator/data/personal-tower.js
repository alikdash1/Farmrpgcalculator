// Empty on purpose: this copy ships with no account. Connect the extension or
// load a saved account file and the planner fills in your own masteries.
window.FRPG_PERSONAL_TOWER = {
  "schema": "farmrpg-personal-tower-v1",
  "clean": true,
  "authoritativeMasteries": false,
  "startFloor": 0,
  "goalFloor": 350,
  "towerAtCapture": 0,
  "capturedAt": null,
  "overrides": [],
  "masteries": {}
};